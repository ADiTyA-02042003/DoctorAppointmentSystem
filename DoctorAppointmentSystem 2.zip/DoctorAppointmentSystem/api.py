from flask import Flask, jsonify, request
from database import get_db_connection  # Ensure this function is properly defined

app = Flask(__name__)

@app.route('/doctors', methods=['GET'])
def get_doctors():
    """ Fetch all doctors, optionally filtered by specialization with pagination """
    specialization = request.args.get('specialization')
    page = int(request.args.get('page', 1))
    limit = int(request.args.get('limit', 5))  # Default 5 doctors per page
    offset = (page - 1) * limit

    conn = get_db_connection()
    cursor = conn.cursor()

    if specialization:
        cursor.execute("SELECT * FROM doctors WHERE specialization = ? LIMIT ? OFFSET ?", (specialization, limit, offset))
    else:
        cursor.execute("SELECT * FROM doctors LIMIT ? OFFSET ?", (limit, offset))

    doctors = cursor.fetchall()
    conn.close()

    if not doctors:
        return jsonify({"error": "No doctors found"}), 404

    doctors_list = [dict(row) for row in doctors]
    
    return jsonify({"page": page, "limit": limit, "doctors": doctors_list})

@app.route('/doctors/<int:doctor_id>', methods=['GET'])
def get_doctor_by_id(doctor_id):
    """ Fetch doctor details by ID """
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM doctors WHERE id = ?", (doctor_id,))
    doctor = cursor.fetchone()
    conn.close()

    if not doctor:
        return jsonify({"error": "Doctor not found"}), 404

    return jsonify(dict(doctor))

@app.route('/doctors', methods=['POST'])
def add_doctor():
    """ Add a new doctor """
    data = request.json
    if not all(key in data for key in ["name", "specialization", "degree", "availability"]):
        return jsonify({"error": "Missing fields"}), 400

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO doctors (name, specialization, degree, availability) VALUES (?, ?, ?, ?)",
                   (data["name"], data["specialization"], data["degree"], data["availability"]))
    conn.commit()
    conn.close()

    return jsonify({"message": "Doctor added successfully"}), 201

@app.route('/doctors/<int:doctor_id>', methods=['PUT'])
def update_doctor(doctor_id):
    """ Update a doctor's details """
    data = request.json
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("SELECT * FROM doctors WHERE id = ?", (doctor_id,))
    if not cursor.fetchone():
        return jsonify({"error": "Doctor not found"}), 404

    cursor.execute("UPDATE doctors SET name = ?, specialization = ?, degree = ?, availability = ? WHERE id = ?",
                   (data["name"], data["specialization"], data["degree"], data["availability"], doctor_id))
    conn.commit()
    conn.close()

    return jsonify({"message": "Doctor updated successfully"})

@app.route('/doctors/<int:doctor_id>', methods=['DELETE'])
def delete_doctor(doctor_id):
    """ Delete a doctor by ID """
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("SELECT * FROM doctors WHERE id = ?", (doctor_id,))
    if not cursor.fetchone():
        return jsonify({"error": "Doctor not found"}), 404

    cursor.execute("DELETE FROM doctors WHERE id = ?", (doctor_id,))
    conn.commit()
    conn.close()

    return jsonify({"message": "Doctor deleted successfully"}), 200

if __name__ == '__main__':
    app.run(debug=True)
