import tkinter as tk
from tkinter import messagebox, ttk
import sqlite3
from datetime import datetime
from tkcalendar import DateEntry


# Function to fetch patients
def fetch_patients():
    conn = sqlite3.connect('hospital.db')
    cursor = conn.cursor()
    cursor.execute("SELECT id, name FROM patients")
    patients = cursor.fetchall()
    conn.close()
    return patients

# Function to fetch available doctors
def fetch_available_doctors():
    conn = sqlite3.connect('hospital.db')
    cursor = conn.cursor()
    cursor.execute("SELECT id, name, specialization FROM doctors WHERE availability = 'Available'")
    doctors = cursor.fetchall()
    conn.close()
    return doctors



# Function to fetch available slots for a doctor
def fetch_available_slots(doctor_id, date):
    all_slots = ["09:00 AM", "10:00 AM", "11:00 AM", "02:00 PM", "03:00 PM"]
    available_slots = [slot for slot in all_slots if is_slot_available(doctor_id, date, slot)]
    return available_slots


# Function to check if a slot is available
def is_slot_available(doctor_id, date, time):
    conn = sqlite3.connect('hospital.db')
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM appointments WHERE doctor_id = ? AND date = ? AND time = ?", 
                   (doctor_id, date, time))
    count = cursor.fetchone()[0]
    conn.close()
    return count == 0


# Function to book an appointment
def book_appointment(patient_id, doctor_id, date, time, illness):
    if not patient_id or not doctor_id or not date or not time or not illness:
        messagebox.showerror("Error", "All fields are required!")
        return

    conn = sqlite3.connect('hospital.db')
    cursor = conn.cursor()
    cursor.execute("INSERT INTO appointments (patient_id, doctor_id, date, time, illness) VALUES (?, ?, ?, ?, ?)",
                   (patient_id, doctor_id, date, time, illness))
    conn.commit()
    conn.close()

    messagebox.showinfo("Success", "Appointment booked successfully!")


# Function to edit an appointment
def edit_appointment(appt_id, doctor_id, new_date, new_time):
    if not is_slot_available(doctor_id, new_date, new_time):
        messagebox.showerror("Error", "This slot is already booked!")
        return
    
    conn = sqlite3.connect('hospital.db')
    cursor = conn.cursor()
    cursor.execute("UPDATE appointments SET date = ?, time = ? WHERE id = ?", (new_date, new_time, appt_id))
    conn.commit()
    conn.close()
    messagebox.showinfo("Success", "Appointment updated successfully!")

# # Function to cancel an appointment
# def cancel_appointment(appt_id):
#     conn = sqlite3.connect('hospital.db')
#     cursor = conn.cursor()
#     cursor.execute("DELETE FROM appointments WHERE id = ?", (appt_id,))
#     conn.commit()
#     conn.close()
#     messagebox.showinfo("Success", "Appointment canceled successfully!")



# Function to cancel an appointment
def cancel_appointment(appt_id):
    conn = sqlite3.connect('hospital.db')
    cursor = conn.cursor()
    cursor.execute("DELETE FROM appointments WHERE id = ?", (appt_id,))
    conn.commit()
    conn.close()
    messagebox.showinfo("Success", "Appointment canceled successfully!")



# Function to generate time slots based on selected shift
def generate_time_slots(shift):
    morning_slots = ["09:00 AM", "09:30 AM", "10:00 AM", "10:30 AM", "11:00 AM", "11:30 AM"]
    afternoon_slots = ["12:00 PM", "12:30 PM", "02:00 PM", "02:30 PM", "03:00 PM", "03:30 PM"]
    evening_slots = ["04:00 PM", "04:30 PM", "05:00 PM", "05:30 PM", "06:00 PM", "06:30 PM", "07:00 PM", "07:30 PM"]

    if shift == "Morning":
        return morning_slots
    elif shift == "Afternoon":
        return afternoon_slots
    elif shift == "Evening":
        return evening_slots
    return []

# Appointment Booking Form
def open_booking_form():
    booking_window = tk.Toplevel()
    booking_window.title("Book Appointment")
    booking_window.geometry("400x450")

    tk.Label(booking_window, text="Select Patient:").pack()
    patients = fetch_patients()
    patient_var = tk.StringVar()
    patient_dropdown = ttk.Combobox(booking_window, textvariable=patient_var, values=[f"{p[0]} - {p[1]}" for p in patients])
    patient_dropdown.pack()

    tk.Label(booking_window, text="Select Doctor:").pack()
    doctors = fetch_available_doctors()
    doctor_var = tk.StringVar()
    doctor_dropdown = ttk.Combobox(booking_window, textvariable=doctor_var, values=[f"{d[0]} - Dr. {d[1]}" for d in doctors])
    doctor_dropdown.pack()

    tk.Label(booking_window, text="Select Date:").pack()
    date_entry = DateEntry(booking_window)
    date_entry.pack()

    tk.Label(booking_window, text="Select Shift:").pack()

    time_var = tk.StringVar()
    time_dropdown = ttk.Combobox(booking_window, textvariable=time_var)
    time_dropdown.pack()

    def update_time_slots(shift):
        available_slots = generate_time_slots(shift)
        time_dropdown["values"] = available_slots
        if available_slots:
            time_var.set(available_slots[0])  # Auto-select the first available slot

    # Buttons for shifts
    tk.Button(booking_window, text="Morning (9 AM - 12 PM)", command=lambda: update_time_slots("Morning")).pack(pady=2)
    tk.Button(booking_window, text="Afternoon (12 PM - 4 PM)", command=lambda: update_time_slots("Afternoon")).pack(pady=2)
    tk.Button(booking_window, text="Evening (4 PM - 8 PM)", command=lambda: update_time_slots("Evening")).pack(pady=2)

    tk.Label(booking_window, text="Illness / Medical Concern:").pack()
    illness_entry = tk.Entry(booking_window)
    illness_entry.pack()

    def submit_appointment():
        selected_patient = patient_var.get().split(" - ")[0] if patient_var.get() else None
        selected_doctor = doctor_var.get().split(" - ")[0] if doctor_var.get() else None
        book_appointment(selected_patient, selected_doctor, date_entry.get(), time_var.get(), illness_entry.get())

    tk.Button(booking_window, text="Book Appointment", command=submit_appointment).pack(pady=10)





# # Appointment Booking Form
# def open_booking_form():
#     booking_window = tk.Toplevel()
#     booking_window.title("Book Appointment")
#     booking_window.geometry("400x350")
    
#     tk.Label(booking_window, text="Select Patient:").pack()
#     patients = fetch_patients()
#     patient_var = tk.StringVar()
#     patient_dropdown = ttk.Combobox(booking_window, textvariable=patient_var, values=[f"{p[0]} - {p[1]}" for p in patients])
#     patient_dropdown.pack()
    
#     tk.Label(booking_window, text="Select Doctor:").pack()
#     doctors = fetch_available_doctors()
#     doctor_var = tk.StringVar()
#     doctor_dropdown = ttk.Combobox(booking_window, textvariable=doctor_var, values=[f"{d[0]} - Dr. {d[1]}" for d in doctors])
#     doctor_dropdown.pack()
    
#     tk.Label(booking_window, text="Select Date:").pack()
#     date_entry = DateEntry(booking_window)
#     date_entry.pack()
    
#     tk.Label(booking_window, text="Select Time:").pack()
#     time_var = tk.StringVar()
#     time_dropdown = ttk.Combobox(booking_window, textvariable=time_var, values=["09:00 AM", "09:30 AM", "10:00 AM", "10:30 PM", "11:00 PM","11:30 AM", "12:00 AM", "12:30 AM", "02:00 PM", "02:30 PM","03:00 AM", "03:30 AM", "04:00 AM", "04:30 PM", "05:00 PM","05:30 AM", "06:00 AM", "06:30 AM", "07:00 PM", "07:30 PM","08:00 PM"])
#     time_dropdown.pack()
    
#     def submit_appointment():
#         selected_patient = patient_var.get().split(" - ")[0] if patient_var.get() else None
#         selected_doctor = doctor_var.get().split(" - ")[0] if doctor_var.get() else None
#         book_appointment(selected_patient, selected_doctor, date_entry.get(), time_var.get())
    
#     tk.Button(booking_window, text="Book Appointment", command=submit_appointment).pack(pady=10)




# Function to register a new patient
def register_patient(name, age, phone, email, patient_dropdown):
    if not name or not age or not phone or not email:
        messagebox.showerror("Error", "All fields are required!")
        return

    conn = sqlite3.connect('hospital.db')
    cursor = conn.cursor()
    cursor.execute("INSERT INTO patients (name, age, phone, email) VALUES (?, ?, ?, ?)", 
                   (name, age, phone, email))
    conn.commit()
    conn.close()

    messagebox.showinfo("Success", "Patient registered successfully!")

    # Refresh patient dropdown
    patients = fetch_patients()
    patient_dropdown["values"] = [f"{p[0]} - {p[1]}" for p in patients]



# Patient Registration Form
def open_patient_registration(patient_dropdown):
    reg_window = tk.Toplevel()
    reg_window.title("Register New Patient")
    reg_window.geometry("400x350")

    tk.Label(reg_window, text="Register New Patient", font=("Arial", 14, "bold")).pack(pady=10)

    tk.Label(reg_window, text="Patient Name:").pack()
    name_entry = tk.Entry(reg_window)
    name_entry.pack()

    tk.Label(reg_window, text="Age:").pack()
    age_entry = tk.Entry(reg_window)
    age_entry.pack()

    tk.Label(reg_window, text="Phone Number:").pack()
    phone_entry = tk.Entry(reg_window)
    phone_entry.pack()

    tk.Label(reg_window, text="Email:").pack()
    email_entry = tk.Entry(reg_window)
    email_entry.pack()

    def submit_patient():
        register_patient(name_entry.get(), age_entry.get(), phone_entry.get(), email_entry.get(), patient_dropdown)

    tk.Button(reg_window, text="Register", command=submit_patient).pack(pady=10)




# Function to manage appointments
def open_appointment_list():
    appointments_window = tk.Toplevel()
    appointments_window.title("Appointments List")
    appointments_window.geometry("800x600")

    tk.Label(appointments_window, text="All Appointments", font=("Arial", 14, "bold")).pack(pady=10)

    conn = sqlite3.connect('hospital.db')
    cursor = conn.cursor()
    cursor.execute("SELECT a.id, p.name, d.name, a.date, a.time ,a.illness FROM appointments a JOIN patients p ON a.patient_id = p.id JOIN doctors d ON a.doctor_id = d.id")
    appointments = cursor.fetchall()
    conn.close()

    tree = ttk.Treeview(appointments_window, columns=("ID", "Patient", "Doctor", "Date", "Time","Illness"), show="headings")
    tree.heading("ID", text="ID")
    tree.heading("Patient", text="Patient")
    tree.heading("Doctor", text="Doctor")
    tree.heading("Date", text="Date")
    tree.heading("Time", text="Time")
    tree.heading("Illness", text="Illness")


    for appt in appointments:
        tree.insert("", "end", values=appt)

    tree.pack(expand=True, fill="both")

    def edit_selected():
        selected_item = tree.selection()
        if not selected_item:
            messagebox.showerror("Error", "Please select an appointment to edit")
            return
        appt_values = tree.item(selected_item)['values']
        appt_id = appt_values[0]  # Appointment ID
        doctor_name = appt_values[2]  # Doctor's name (column 3)
        
        # Fetch doctor_id from database using doctor_name
        conn = sqlite3.connect('hospital.db')
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM doctors WHERE name = ?", (doctor_name,))
        result = cursor.fetchone()
        conn.close()

        if result:
            doctor_id = result[0]  # Extract doctor_id
            edit_appointment(appt_id, doctor_id, date_entry.get(), time_var.get())
        else:
            messagebox.showerror("Error", "Doctor not found in the database.")

    def cancel_selected():
        selected_item = tree.selection()
        if not selected_item:
            messagebox.showerror("Error", "Please select an appointment to cancel")
            return
        appt_id = tree.item(selected_item)['values'][0]
        cancel_appointment(appt_id)
        tree.delete(selected_item)

    # Label for date selection
    tk.Label(appointments_window, text="Select New Date:").pack()
    date_entry = DateEntry(appointments_window)
    date_entry.pack()

    # Label for time selection
    tk.Label(appointments_window, text="Select Shift:").pack()

    time_var = tk.StringVar()
    time_dropdown = ttk.Combobox(appointments_window, textvariable=time_var)
    time_dropdown.pack()

    def update_time_slots(shift):
        available_slots = generate_time_slots(shift)
        time_dropdown["values"] = available_slots
        if available_slots:
            time_var.set(available_slots[0])  # Auto-select the first available slot

    # Buttons for shifts
    tk.Button(appointments_window, text="Morning (9 AM - 12 PM)", command=lambda: update_time_slots("Morning")).pack(pady=2)
    tk.Button(appointments_window, text="Afternoon (12 PM - 4 PM)", command=lambda: update_time_slots("Afternoon")).pack(pady=2)
    tk.Button(appointments_window, text="Evening (4 PM - 8 PM)", command=lambda: update_time_slots("Evening")).pack(pady=2)



    tk.Button(appointments_window, text="Edit Appointment", command=edit_selected).pack(pady=5)
    tk.Button(appointments_window, text="Cancel Appointment", command=cancel_selected).pack(pady=5)


# Function to open the doctor search window
def open_doctor_search():
    search_window = tk.Toplevel()
    search_window.title("Search for a Doctor")
    search_window.geometry("400x400")
    
    tk.Label(search_window, text="Search Doctor by Name or Specialization:").pack()
    search_var = tk.StringVar()
    search_entry = ttk.Entry(search_window, textvariable=search_var)
    search_entry.pack()
    
    doctor_listbox = tk.Listbox(search_window)
    doctor_listbox.pack(fill=tk.BOTH, expand=True)
    
    def update_listbox():
        doctor_listbox.delete(0, tk.END)
        query = search_var.get().lower()
        doctors = fetch_available_doctors()
        
        for doctor in doctors:
            if len(doctor) < 3:
                continue  # Skip improperly structured records

            doctor_id, doctor_name, specialization = doctor
            if query in doctor_name.lower() or query in specialization.lower():
                doctor_listbox.insert(tk.END, f"{doctor_id} - Dr. {doctor_name} ({specialization})")

    
    search_entry.bind("<KeyRelease>", lambda event: update_listbox())
    
    def show_available_slots():
        selected = doctor_listbox.get(tk.ACTIVE)
        if not selected:
            return
        doctor_id = selected.split(" - ")[0]
        date = date_entry.get()
        available_slots = fetch_available_slots(doctor_id, date)
        slots_dropdown["values"] = available_slots
    
    tk.Label(search_window, text="Select Date:").pack()
    date_entry = DateEntry(search_window)
    date_entry.pack()
    
    tk.Button(search_window, text="Show Available Slots", command=show_available_slots).pack()
    
    tk.Label(search_window, text="Available Slots:").pack()
    slots_dropdown = ttk.Combobox(search_window)
    slots_dropdown.pack()
    
    tk.Button(search_window, text="Close", command=search_window.destroy).pack(pady=10)




# Receptionist Dashboard UI
def receptionist_dashboard():
    root = tk.Tk()
    root.title("Receptionist Dashboard")
    root.geometry("800x600")

    tk.Label(root, text="Receptionist Dashboard", font=("Arial", 16, "bold")).pack(pady=10)
    
    tk.Button(root, text="Register New Patient", command=lambda: open_patient_registration(None), width=30).pack(pady=5)

    tk.Button(root, text="Book New Appointment", command=open_booking_form, width=30).pack(pady=5)

    tk.Button(root, text="View Appointments", command=open_appointment_list, width=30).pack(pady=5)

    tk.Button(root, text="Search for a Doctor", command=open_doctor_search, width=30).pack(pady=5)
    


    root.mainloop()





if __name__ == "__main__":
    receptionist_dashboard()
