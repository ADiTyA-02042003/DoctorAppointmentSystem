from database import create_tables
import gui

def setup_database():
    print("Setting up database...")
    create_tables()
    print("Database ready!")

def start_application():
    print("Starting Doctor Appointment System...")
    gui.root.mainloop()

if __name__ == "__main__":
    setup_database()
    start_application()
