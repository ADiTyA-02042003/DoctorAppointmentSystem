# fastapi_server.py
from fastapi import FastAPI

app = FastAPI()

@app.get("/")
def read_root():
    return {"message": "Welcome to the Doctor Appointment System API"}

@app.get("/register")
def register():
    return {"message": "Registration endpoint"}

@app.get("/login")
def login():
    return {"message": "Login endpoint"}