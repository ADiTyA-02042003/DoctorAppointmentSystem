import tkinter as tk
from tkinter import ttk, messagebox
from models import Doctor, Patient, Appointment  # Import classes from models.py

root = tk.Tk()
root.title("Doctor Appointment System")
root.geometry("700x500")

notebook = ttk.Notebook(root)
tab_doctor = ttk.Frame(notebook)
tab_patient = ttk.Frame(notebook)
tab_appointment = ttk.Frame(notebook)

notebook.add(tab_doctor, text="Doctors")
notebook.add(tab_patient, text="Patients")
notebook.add(tab_appointment, text="Appointments")

notebook.pack(expand=True, fill="both")

def add_doctor():
    name = doctor_name_entry.get().strip()
    specialization = doctor_specialization_entry.get().strip()
    
    if name and specialization:
        doctor = Doctor(name, specialization)
        doctor.save_to_db()
        messagebox.showinfo("Success", "Doctor added successfully!")
        update_doctor_list()
        doctor_name_entry.delete(0, tk.END)
        doctor_specialization_entry.delete(0, tk.END)
    else:
        messagebox.showwarning("Input Error", "Please enter all details.")

def delete_doctor():
    selected_item = doctor_list.selection()
    if selected_item:
        doctor_id = doctor_list.item(selected_item)['values'][0]
        Doctor.delete_doctor(doctor_id)
        messagebox.showinfo("Success", "Doctor deleted successfully!")
        update_doctor_list()
    else:
        messagebox.showwarning("Selection Error", "Please select a doctor to delete.")

tk.Label(tab_doctor, text="Doctor Name:").pack()
doctor_name_entry = tk.Entry(tab_doctor)
doctor_name_entry.pack()

tk.Label(tab_doctor, text="Specialization:").pack()
doctor_specialization_entry = tk.Entry(tab_doctor)
doctor_specialization_entry.pack()

tk.Button(tab_doctor, text="Add Doctor", command=add_doctor).pack()
tk.Button(tab_doctor, text="Delete Doctor", command=delete_doctor).pack()

doctor_list = ttk.Treeview(tab_doctor, columns=("ID", "Name", "Specialization"), show="headings")
doctor_list.heading("ID", text="ID")
doctor_list.heading("Name", text="Name")
doctor_list.heading("Specialization", text="Specialization")
doctor_list.pack(fill="both", expand=True)

def update_doctor_list():
    for row in doctor_list.get_children():
        doctor_list.delete(row)
    for doctor in Doctor.get_all_doctors():
        doctor_list.insert("", "end", values=doctor)

update_doctor_list()

def add_patient():
    name = patient_name_entry.get().strip()
    age = patient_age_entry.get().strip()
    phone = patient_phone_entry.get().strip()
    
    if name and age.isdigit() and phone.isdigit():
        patient = Patient(name, int(age), phone)
        patient.save_to_db()
        messagebox.showinfo("Success", "Patient added successfully!")
        update_patient_list()
        patient_name_entry.delete(0, tk.END)
        patient_age_entry.delete(0, tk.END)
        patient_phone_entry.delete(0, tk.END)
    else:
        messagebox.showwarning("Input Error", "Please enter valid details.")

def delete_patient():
    selected_item = patient_list.selection()
    if selected_item:
        patient_id = patient_list.item(selected_item)['values'][0]
        Patient.delete_patient(patient_id)
        messagebox.showinfo("Success", "Patient deleted successfully!")
        update_patient_list()
    else:
        messagebox.showwarning("Selection Error", "Please select a patient to delete.")

tk.Label(tab_patient, text="Patient Name:").pack()
patient_name_entry = tk.Entry(tab_patient)
patient_name_entry.pack()

tk.Label(tab_patient, text="Age:").pack()
patient_age_entry = tk.Entry(tab_patient)
patient_age_entry.pack()

tk.Label(tab_patient, text="Phone:").pack()
patient_phone_entry = tk.Entry(tab_patient)
patient_phone_entry.pack()

tk.Button(tab_patient, text="Add Patient", command=add_patient).pack()
tk.Button(tab_patient, text="Delete Patient", command=delete_patient).pack()

patient_list = ttk.Treeview(tab_patient, columns=("ID", "Name", "Age", "Phone"), show="headings")
patient_list.heading("ID", text="ID")
patient_list.heading("Name", text="Name")
patient_list.heading("Age", text="Age")
patient_list.heading("Phone", text="Phone")
patient_list.pack(fill="both", expand=True)

def update_patient_list():
    for row in patient_list.get_children():
        patient_list.delete(row)
    for patient in Patient.get_all_patients():
        patient_list.insert("", "end", values=patient)

update_patient_list()

def book_appointment():
    patient_id = patient_id_entry.get().strip()
    doctor_id = doctor_id_entry.get().strip()
    date = appointment_date_entry.get().strip()
    time = appointment_time_entry.get().strip()
    
    if patient_id.isdigit() and doctor_id.isdigit() and date and time:
        appointment = Appointment(int(patient_id), int(doctor_id), date, time)
        appointment.save_to_db()
        messagebox.showinfo("Success", "Appointment booked successfully!")
        update_appointment_list()
        patient_id_entry.delete(0, tk.END)
        doctor_id_entry.delete(0, tk.END)
        appointment_date_entry.delete(0, tk.END)
        appointment_time_entry.delete(0, tk.END)
    else:
        messagebox.showwarning("Input Error", "Please enter valid details.")

def delete_appointment():
    selected_item = appointment_list.selection()
    if selected_item:
        appointment_id = appointment_list.item(selected_item)['values'][0]
        Appointment.delete_appointment(appointment_id)
        messagebox.showinfo("Success", "Appointment deleted successfully!")
        update_appointment_list()
    else:
        messagebox.showwarning("Selection Error", "Please select an appointment to delete.")

tk.Label(tab_appointment, text="Patient ID:").pack()
patient_id_entry = tk.Entry(tab_appointment)
patient_id_entry.pack()

tk.Label(tab_appointment, text="Doctor ID:").pack()
doctor_id_entry = tk.Entry(tab_appointment)
doctor_id_entry.pack()

tk.Label(tab_appointment, text="Date (YYYY-MM-DD):").pack()
appointment_date_entry = tk.Entry(tab_appointment)
appointment_date_entry.pack()

tk.Label(tab_appointment, text="Time (HH:MM):").pack()
appointment_time_entry = tk.Entry(tab_appointment)
appointment_time_entry.pack()

tk.Button(tab_appointment, text="Book Appointment", command=book_appointment).pack()
tk.Button(tab_appointment, text="Delete Appointment", command=delete_appointment).pack()

appointment_list = ttk.Treeview(tab_appointment, columns=("ID", "Patient", "Doctor", "Date", "Time"), show="headings")
appointment_list.heading("ID", text="ID")
appointment_list.heading("Patient", text="Patient")
appointment_list.heading("Doctor", text="Doctor")
appointment_list.heading("Date", text="Date")
appointment_list.heading("Time", text="Time")
appointment_list.pack(fill="both", expand=True)

def update_appointment_list():
    for row in appointment_list.get_children():
        appointment_list.delete(row)
    for appointment in Appointment.get_all_appointments():
        appointment_list.insert("", "end", values=appointment)

update_appointment_list()

root.mainloop()
