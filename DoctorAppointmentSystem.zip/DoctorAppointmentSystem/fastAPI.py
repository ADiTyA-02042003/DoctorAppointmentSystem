"""
To run the fastAPI file first execute " python fastAPI.py" in terminal

then execute "uvicorn fastAPI:app --reload"

"""


"""
How to run in Postman??

# ----------------------- Doctor Endpoints -----------------------

1. Add Doctor
URL: http://127.0.0.1:8000/add_doctors
Method: POST
Payload (JSON):
json
Copy
Edit
{
  "name": "Dr. John Doe",
  "specialization": "Cardiology",
  "degree": "MBBS, MD",
  "email": "johndoe@example.com"
}
Response:
json
Copy
Edit
{ "message": "Doctor added successfully" }




2. View All Doctors
URL: http://127.0.0.1:8000/view_doctors?page=1&limit=5
Method: GET
Response:
json
Copy
Edit
[
  {
    "id": 1,
    "name": "Dr. John Doe",
    "specialization": "Cardiology",
    "degree": "MBBS, MD",
    "email": "johndoe@example.com"
  }
]



3. Get Doctor by ID
URL: http://127.0.0.1:8000/get_doctor_by_id_doctors/{doctor_id}
Method: GET
Example: http://127.0.0.1:8000/get_doctor_by_id_doctors/1
Response:
json
Copy
Edit
{
  "id": 1,
  "name": "Dr. John Doe",
  "specialization": "Cardiology",
  "degree": "MBBS, MD",
  "email": "johndoe@example.com"
}



4. Update Doctor
URL: http://127.0.0.1:8000/update_doctors/{doctor_id}
Method: PUT
Example: http://127.0.0.1:8000/update_doctors/1
Payload (JSON):
json
Copy
Edit
{
  "name": "Dr. John Smith",
  "specialization": "Neurology",
  "degree": "MBBS, MD",
  "email": "johnsmith@example.com"
}
Response:
json
Copy
Edit
{ "message": "Doctor updated successfully" }



5. Delete Doctor
URL: http://127.0.0.1:8000/delete_doctors/{doctor_id}
Method: DELETE
Example: http://127.0.0.1:8000/delete_doctors/1
Response:
json
Copy
Edit
{ "message": "Doctor deleted successfully" }





# ----------------------- Patients Endpoints -----------------------
1. Add Patient
URL: http://127.0.0.1:8000/add_patients
Method: POST
Payload (JSON):
json
Copy
Edit
{
  "name": "Jane Doe",
  "age": 29,
  "phone": "9876543210",
  "email": "janedoe@example.com"
}
Response:
json
Copy
Edit
{ "message": "Patient registered successfully" }



2. View All Patients
URL: http://127.0.0.1:8000/get_patients
Method: GET
Response:
json
Copy
Edit
[
  {
    "id": 1,
    "name": "Jane Doe",
    "age": 29,
    "phone": "9876543210",
    "email": "janedoe@example.com"
  }
]


# ----------------------- Appointment Endpoints -----------------------
1. Book Appointment
URL: http://127.0.0.1:8000/book_appointment
Method: POST
Payload (JSON):
json
Copy
Edit
{
  "patient_id": 1,
  "doctor_id": 1,
  "date": "2024-02-29",
  "time": "10:30 AM",
  "illness": "Fever"
}
Response:
json
Copy
Edit
{ "message": "Appointment booked successfully" }


2. Update Appointment
URL: http://127.0.0.1:8000/update_appointments
Method: PUT
Payload (JSON):
json
Copy
Edit
{
  "appt_id": 1,
  "new_date": "2024-03-01",
  "new_time": "11:00 AM"
}
Response:
json
Copy
Edit
{ "message": "Appointment updated successfully" }
3. Cancel Appointment
URL: http://127.0.0.1:8000/cancel_appointments/{appt_id}
Method: DELETE
Example: http://127.0.0.1:8000/cancel_appointments/1
Response:
json
Copy
Edit
{ "message": "Appointment canceled successfully" }



"""


from fastapi import FastAPI, Depends, HTTPException
from pydantic import BaseModel
import sqlite3
from typing import List, Optional
from database import get_db_connection  # Ensure this function is properly defined

app = FastAPI()

# ----------------------- Database Dependency -----------------------
def get_db():
    conn = get_db_connection()
    try:
        yield conn
    finally:
        conn.close()

# ----------------------- Pydantic Models -----------------------
class Doctor(BaseModel):
    name: str
    specialization: str
    degree: str
    email: str

class Patient(BaseModel):
    name: str
    age: int
    phone: str
    email: str

class Appointment(BaseModel):
    patient_id: int
    doctor_id: int
    date: str
    time: str
    illness: str

class UpdateAppointment(BaseModel):
    appt_id: int
    doctor_id: int
    new_date: str
    new_time: str

# ----------------------- Doctor Endpoints -----------------------

@app.post("/add_doctors", status_code=201)
def add_doctor(doctor: Doctor, db: sqlite3.Connection = Depends(get_db)):
    """ Add a new doctor """
    cursor = db.cursor()
    cursor.execute(
        "INSERT INTO doctors (name, specialization, degree, email) VALUES (?, ?, ?, ?)",
        (doctor.name, doctor.specialization, doctor.degree, doctor.email)
    )
    db.commit()
    return {"message": "Doctor added successfully"}

@app.get("/view_doctors", response_model=List[dict])
def get_doctors(specialization: Optional[str] = None, page: int = 1, limit: int = 5, db: sqlite3.Connection = Depends(get_db)):
    """ Fetch all doctors with optional specialization & pagination """
    offset = (page - 1) * limit
    cursor = db.cursor()
    
    if specialization:
        cursor.execute("SELECT * FROM doctors WHERE specialization = ? LIMIT ? OFFSET ?", (specialization, limit, offset))
    else:
        cursor.execute("SELECT * FROM doctors LIMIT ? OFFSET ?", (limit, offset))
    
    doctors = cursor.fetchall()
    if not doctors:
        raise HTTPException(status_code=404, detail="No doctors found")

    return [dict(doctor) for doctor in doctors]

@app.get("/get_doctor_by_id_doctors/{doctor_id}", response_model=dict)
def get_doctor_by_id(doctor_id: int, db: sqlite3.Connection = Depends(get_db)):
    cursor = db.cursor()
    cursor.execute("SELECT * FROM doctors WHERE id = ?", (doctor_id,))
    doctor = cursor.fetchone()
    
    if doctor is None:
        raise HTTPException(status_code=404, detail="Doctor not found")

    return dict(doctor)

@app.put("/update_doctors/{doctor_id}")
def update_doctor(doctor_id: int, doctor: Doctor, db: sqlite3.Connection = Depends(get_db)):
    cursor = db.cursor()
    cursor.execute("SELECT * FROM doctors WHERE id = ?", (doctor_id,))
    if not cursor.fetchone():
        raise HTTPException(status_code=404, detail="Doctor not found")

    cursor.execute(
        "UPDATE doctors SET name = ?, specialization = ?, degree = ?, email = ? WHERE id = ?",
        (doctor.name, doctor.specialization, doctor.degree, doctor.email, doctor_id)
    )
    db.commit()
    return {"message": "Doctor updated successfully"}

@app.delete("/delete_doctors/{doctor_id}")
def delete_doctor(doctor_id: int, db: sqlite3.Connection = Depends(get_db)):
    cursor = db.cursor()
    cursor.execute("SELECT * FROM doctors WHERE id = ?", (doctor_id,))
    if not cursor.fetchone():
        raise HTTPException(status_code=404, detail="Doctor not found")

    cursor.execute("DELETE FROM doctors WHERE id = ?", (doctor_id,))
    db.commit()
    return {"message": "Doctor deleted successfully"}

# ----------------------- Patient Endpoints -----------------------

@app.post("/add_patients", status_code=201)
def add_patient(patient: Patient, db: sqlite3.Connection = Depends(get_db)):
    """ Register a new patient """
    cursor = db.cursor()
    cursor.execute(
        "INSERT INTO patients (name, age, phone, email) VALUES (?, ?, ?, ?)",
        (patient.name, patient.age, patient.phone, patient.email)
    )
    db.commit()
    return {"message": "Patient registered successfully"}

@app.get("/get_patients", response_model=List[dict])
def get_patients(db: sqlite3.Connection = Depends(get_db)):
    cursor = db.cursor()
    cursor.execute("SELECT * FROM patients ORDER BY id")
    patients = cursor.fetchall()
    
    if not patients:
        raise HTTPException(status_code=404, detail="No patients found")

    return [dict(patient) for patient in patients]

# ----------------------- Appointments Endpoints -----------------------

@app.post("/book_appointment", status_code=201)
def create_appointment(appointment: Appointment, db: sqlite3.Connection = Depends(get_db)):
    """ Create a new appointment """
    cursor = db.cursor()
    cursor.execute(
        "INSERT INTO appointments (patient_id, doctor_id, date, time, illness) VALUES (?, ?, ?, ?, ?)",
        (appointment.patient_id, appointment.doctor_id, appointment.date, appointment.time, appointment.illness)
    )
    db.commit()
    return {"message": "Appointment booked successfully"}

@app.put("/update_appointments")
def update_appointment(data: UpdateAppointment, db: sqlite3.Connection = Depends(get_db)):
    """ Update an existing appointment """
    cursor = db.cursor()
    cursor.execute("SELECT * FROM appointments WHERE id = ?", (data.appt_id,))
    appointment = cursor.fetchone()

    if not appointment:
        raise HTTPException(status_code=404, detail="Appointment not found")

    cursor.execute("UPDATE appointments SET date = ?, time = ? WHERE id = ?", (data.new_date, data.new_time, data.appt_id))
    db.commit()
    return {"message": "Appointment updated successfully"}

@app.delete("/cancel_appointments/{appt_id}")
def cancel_appointment(appt_id: int, db: sqlite3.Connection = Depends(get_db)):
    """ Cancel an appointment """
    cursor = db.cursor()
    cursor.execute("SELECT * FROM appointments WHERE id = ?", (appt_id,))
    appointment = cursor.fetchone()

    if not appointment:
        raise HTTPException(status_code=404, detail="Appointment not found")

    cursor.execute("DELETE FROM appointments WHERE id = ?", (appt_id,))
    db.commit()
    return {"message": "Appointment canceled successfully"}

# ----------------------- Running the FastAPI Server -----------------------

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000, reload=True)
