import sqlite3
import bcrypt
import jwt
import datetime

SECRET_KEY = "your_secret_key"  # Change this to a secure key

# Global variable to store receptionist session
receptionist_session = {}

class Auth:
    @staticmethod
    def register_receptionist(name, email, password):
        hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
        conn = sqlite3.connect('hospital.db')
        cursor = conn.cursor()
        try:
            cursor.execute("INSERT INTO users (name, email, password) VALUES (?, ?, ?)", 
                           (name, email, hashed_password))
            conn.commit()
            return "Registration Successful"
        except sqlite3.IntegrityError:
            return "Email already exists!"
        finally:
            conn.close()

    @staticmethod
    def login(email, password):
        conn = sqlite3.connect('hospital.db')
        cursor = conn.cursor()
        cursor.execute("SELECT id, name, password FROM users WHERE email=?", (email,))
        user = cursor.fetchone()
        conn.close()

        if user:
            user_id, name, hashed_password = user
            if bcrypt.checkpw(password.encode('utf-8'), hashed_password):
                token = jwt.encode(
                    {'user_id': user_id, 'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=2)}, 
                    SECRET_KEY, algorithm="HS256"
                )

                # Store login details in a global dictionary
                receptionist_session["logged_in"] = True
                receptionist_session["user_id"] = user_id
                receptionist_session["user_name"] = name
                receptionist_session["user_email"] = email
                
                return token
            else:
                return "Invalid Password!"
        return "User Not Found!"

    @staticmethod
    def logout():
        """Clear the receptionist session"""
        global receptionist_session
        receptionist_session.clear()  # Clear session manually
        return "Logged out successfully!"

    @staticmethod
    def admin_login(username, password):
        conn = sqlite3.connect('hospital.db')
        cursor = conn.cursor()
        
        cursor.execute("SELECT password FROM admin WHERE username = ?", (username,))
        admin = cursor.fetchone()
        conn.close()
        
        if admin and password == admin[0]:  # Compare stored password
            token = jwt.encode({'role': 'admin', 'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=2)},
                            SECRET_KEY, algorithm="HS256")
            return token
        
        return "Invalid Admin Credentials"

