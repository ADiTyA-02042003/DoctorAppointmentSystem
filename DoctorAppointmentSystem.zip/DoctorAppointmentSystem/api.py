from flask import Flask, jsonify, request
from database import get_db_connection  # Ensure this function is properly defined
from receptionist_dashboard import is_slot_available
app = Flask(__name__)

# ----------------------- Doctor Endpoints -----------------------

@app.route('/doctors', methods=['POST'])
def add_doctor():
    """ Add a new doctor """
    data = request.json
    required_fields = ["name", "specialization", "degree", "email"]

    if not all(key in data for key in required_fields):
        return jsonify({"error": "Missing fields"}), 400

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO doctors (name, specialization, degree, email) VALUES (?, ?, ?, ?)",
        (data["name"], data["specialization"], data["degree"], data["email"])
    )
    conn.commit()
    conn.close()

    return jsonify({"message": "Doctor added successfully"}), 201


@app.route('/alldoctors', methods=['GET'])
def get_doctors():
    """ Fetch all doctors, optionally filtered by specialization with pagination """
    specialization = request.args.get('specialization')
    page = int(request.args.get('page', 1))
    limit = int(request.args.get('limit', 5))  # Default: 5 doctors per page
    offset = (page - 1) * limit

    conn = get_db_connection()
    
    cursor = conn.cursor()

    if specialization:
        cursor.execute(
            "SELECT * FROM doctors WHERE specialization = ? LIMIT ? OFFSET ?", 
            (specialization, limit, offset)
        )
    else:
        cursor.execute("SELECT * FROM doctors LIMIT ? OFFSET ?", (limit, offset))

    doctors = cursor.fetchall()
    conn.close()

    if not doctors:
        return jsonify({"error": "No doctors found"}), 404

    # Convert rows to a list of dictionaries
    doctors = [dict(doct) for doct in doctors]

    return jsonify({"page": page, "limit": limit, "doctors": doctors})


@app.route('/fetchdoctors/<int:doctor_id>', methods=['GET'])
def get_doctor_by_id(doctor_id):
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM doctors WHERE id = ?", (doctor_id,))
    doctor = cursor.fetchone()
    conn.close()

    if doctor is None:
        return jsonify({"error": "Doctor not found"}), 404
    
    # Convert to dictionary
    
    doctor_dict = dict(doctor)  # Convert SQLite Row to Dictionary
    return jsonify(doctor_dict)



@app.route('/updatedoctors/<int:doctor_id>', methods=['PUT'])
def update_doctor(doctor_id):
    """ Update a doctor's details """
    data = request.json

    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM doctors WHERE id = ?", (doctor_id,))
    if not cursor.fetchone():
        return jsonify({"error": "Doctor not found"}), 404

    cursor.execute(
        "UPDATE doctors SET name = ?, specialization = ?, degree = ?, email = ? WHERE id = ?",
        (data["name"], data["specialization"], data["degree"], data["email"], doctor_id)
    )
    conn.commit()
    conn.close()

    return jsonify({"message": "Doctor updated successfully"})


@app.route('/deletedoctors/<int:doctor_id>', methods=['DELETE'])
def delete_doctor(doctor_id):
    """ Delete a doctor by ID """
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM doctors WHERE id = ?", (doctor_id,))
    if not cursor.fetchone():
        return jsonify({"error": "Doctor not found"}), 404

    cursor.execute("DELETE FROM doctors WHERE id = ?", (doctor_id,))
    conn.commit()
    conn.close()

    return jsonify({"message": "Doctor deleted successfully"}), 200


# ----------------------- Patient Endpoints -----------------------

@app.route('/patients', methods=['POST'])
def add_patient():
    """ Register a new patient """
    data = request.json
    required_fields = ["name", "age", "phone", "email"]

    if not all(key in data for key in required_fields):
        return jsonify({"error": "Missing fields"}), 400

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO patients (name, age, phone, email) VALUES (?, ?, ?, ?)", 
        (data["name"], data["age"], data["phone"], data["email"])
    )
    conn.commit()
    conn.close()

    return jsonify({"message": "Patient registered successfully"}), 201



@app.route('/fetchpatients',methods=['GET'])
def get_patient():

    conn=get_db_connection()

    cursor = conn.cursor()

    cursor.execute(
        "SELECT * FROM patients order by id"
    )

    patients= cursor.fetchall()

    conn.close()

    if not patients:
        return jsonify({"error": "No patients found"}), 404
    
    patients=[dict(pat) for pat in patients]

    return jsonify({"patients":patients})




# ----------------------- Appointments Endpoints -----------------------

@app.route('/createappointment',methods=['POST'])

def create_appointment():
    "Create a new appointment"

    data = request.json

    required_fields = ["patient_id", "doctor_id", "date", "time", "illness"]


    # Check if all required fields are present
    if not all(field in data and data[field] for field in required_fields):
        return jsonify({"error": "All fields are required"}), 400
    

    patient_id = data["patient_id"]
    doctor_id = data["doctor_id"]
    date = data["date"]
    time = data["time"]
    illness = data["illness"]

    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO appointments (patient_id, doctor_id, date, time, illness) VALUES (?, ?, ?, ?, ?)",
            (patient_id, doctor_id, date, time, illness),
        )

        conn.commit()
        conn.close()

        return jsonify({"message": "Appointment booked successfully"}), 201


    except Exception as e:
        return jsonify({"error": str(e)}), 500
    


@app.route('/updateappointment', methods=['PUT'])
def update_appointment():
    """Update an existing appointment"""

    data = request.json

    # Required fields
    required_fields = ["appt_id", "doctor_id", "new_date", "new_time"]

    # Validate input
    if not all(field in data and data[field] for field in required_fields):
        return jsonify({"error": "All fields are required"}), 400
    

    appt_id = data["appt_id"]
    doctor_id = data["doctor_id"]
    new_date = data["new_date"]
    new_time = data["new_time"]


    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        # Check if appointment exists
        cursor.execute("SELECT * FROM appointments WHERE id = ?", (appt_id,))
        appointment = cursor.fetchone()
        if not appointment:
            return jsonify({"error": "Appointment not found"}), 404
        

     # Check if the slot is available
        if not is_slot_available(doctor_id, new_date, new_time):
            return jsonify({"error": "This slot is already booked!"}), 400
        

         # Update appointment
        cursor.execute("UPDATE appointments SET date = ?, time = ? WHERE id = ?", (new_date, new_time, appt_id))
        conn.commit()
        conn.close()

        return jsonify({"message": "Appointment updated successfully"}), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500



@app.route('/cancelappointment',methods=['DELETE'])
def cancel_appointment():
    "Cancel an appointment"

    data = request.json

    if "appt_id" not in data or not data["appt_id"]:
        return jsonify({"error : Appointment ID is required"})
    
    appt_id = data["appt_id"]

    try:
        conn = get_db_connection()

        cursor = conn.cursor()

         # Check if the appointment exists
        cursor.execute("SELECT * FROM appointments WHERE id = ?", (appt_id,))
        appointment = cursor.fetchone()

        if not appointment:
            return jsonify({"error": "Appointment not found"}), 404
        

        # Delete appointment
        cursor.execute("DELETE FROM appointments WHERE id = ?", (appt_id,))
        conn.commit()
        conn.close()

        return jsonify({"message": "Appointment canceled successfully"}), 200
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500



if __name__ == '__main__':
    app.run(debug=True)



















# from flask import Flask, jsonify, request
# from database import get_db_connection  # Ensure this function is properly defined

# app = Flask(__name__)

# # ----------------------- Doctor Endpoints -----------------------

# @app.route('/doctors', methods=['POST'])
# def add_doctor():
#     """ Add a new doctor """
#     data = request.json
#     if not all(key in data for key in ["name", "specialization", "degree", "email"]):
#         return jsonify({"error": "Missing fields"}), 400

#     conn = get_db_connection()
#     cursor = conn.cursor()
#     cursor.execute("INSERT INTO doctors (name, specialization, degree, email) VALUES (?, ?, ?, ?)",
#                    (data["name"], data["specialization"], data["degree"], data["email"]))
#     conn.commit()
#     conn.close()

#     return jsonify({"message": "Doctor added successfully"}), 201





# # ----------------------- Patient Endpoints -----------------------

# @app.route('/patients', methods=['POST'])
# def add_patient():
#     """ Register a new patient """
#     data = request.json
#     if not all(key in data for key in ["name", "age", "phone", "email"]):
#         return jsonify({"error": "Missing fields"}), 400

#     conn = get_db_connection()
#     cursor = conn.cursor()
#     cursor.execute("INSERT INTO patients (name, age, phone, email) VALUES (?, ?, ?, ?)", 
#                    (data["name"], data["age"], data["phone"], data["email"]))
#     conn.commit()
#     conn.close()

#     return jsonify({"message": "Patient registered successfully"}), 201



# # @app.route('/doctors', methods=['GET'])
# # def get_doctors():
# #     """ Fetch all doctors, optionally filtered by specialization with pagination """
# #     specialization = request.args.get('specialization')
# #     page = int(request.args.get('page', 1))
# #     limit = int(request.args.get('limit', 5))  # Default 5 doctors per page
# #     offset = (page - 1) * limit

# #     conn = get_db_connection()
# #     cursor = conn.cursor()

# #     if specialization:
# #         cursor.execute("SELECT * FROM doctors WHERE specialization = ? LIMIT ? OFFSET ?", (specialization, limit, offset))
# #     else:
# #         cursor.execute("SELECT * FROM doctors LIMIT ? OFFSET ?", (limit, offset))

# #     doctors = cursor.fetchall()
# #     conn.close()

# #     if not doctors:
# #         return jsonify({"error": "No doctors found"}), 404

# #     doctors_list = [dict(row) for row in doctors]
    
# #     return jsonify({"page": page, "limit": limit, "doctors": doctors_list})






# @app.route('/doctors/<int:doctor_id>', methods=['GET'])
# def get_doctor_by_id(doctor_id):
#     """ Fetch doctor details by ID """
#     conn = get_db_connection()
#     cursor = conn.cursor()
#     cursor.execute("SELECT * FROM doctors WHERE id = ?", (doctor_id,))
#     doctor = cursor.fetchone()
#     conn.close()

#     if not doctor:
#         return jsonify({"error": "Doctor not found"}), 404

#     return jsonify(dict(doctor))

# # @app.route('/doctors', methods=['POST'])
# # def add_doctor():
# #     """ Add a new doctor """
# #     data = request.json
# #     if not all(key in data for key in ["name", "specialization", "degree", "availability"]):
# #         return jsonify({"error": "Missing fields"}), 400

# #     conn = get_db_connection()
# #     cursor = conn.cursor()
# #     cursor.execute("INSERT INTO doctors (name, specialization, degree, availability) VALUES (?, ?, ?, ?)",
# #                    (data["name"], data["specialization"], data["degree"], data["availability"]))
# #     conn.commit()
# #     conn.close()

# #     return jsonify({"message": "Doctor added successfully"}), 201

# # @app.route('/doctors/<int:doctor_id>', methods=['PUT'])
# # def update_doctor(doctor_id):
# #     """ Update a doctor's details """
# #     data = request.json
# #     conn = get_db_connection()
# #     cursor = conn.cursor()
    
# #     cursor.execute("SELECT * FROM doctors WHERE id = ?", (doctor_id,))
# #     if not cursor.fetchone():
# #         return jsonify({"error": "Doctor not found"}), 404

# #     cursor.execute("UPDATE doctors SET name = ?, specialization = ?, degree = ?, availability = ? WHERE id = ?",
# #                    (data["name"], data["specialization"], data["degree"], data["availability"], doctor_id))
# #     conn.commit()
# #     conn.close()

# #     return jsonify({"message": "Doctor updated successfully"})

# # @app.route('/doctors/<int:doctor_id>', methods=['DELETE'])
# # def delete_doctor(doctor_id):
# #     """ Delete a doctor by ID """
# #     conn = get_db_connection()
# #     cursor = conn.cursor()
    
# #     cursor.execute("SELECT * FROM doctors WHERE id = ?", (doctor_id,))
# #     if not cursor.fetchone():
# #         return jsonify({"error": "Doctor not found"}), 404

# #     cursor.execute("DELETE FROM doctors WHERE id = ?", (doctor_id,))
# #     conn.commit()
# #     conn.close()

# #     return jsonify({"message": "Doctor deleted successfully"}), 200

# if __name__ == '__main__':
#     app.run(debug=True)
