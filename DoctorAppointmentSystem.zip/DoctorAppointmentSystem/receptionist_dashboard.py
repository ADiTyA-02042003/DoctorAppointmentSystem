import subprocess
import tkinter as tk
from tkinter import messagebox, ttk
import sqlite3
from datetime import datetime
from tkcalendar import DateEntry
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime, timedelta
# import time
from apscheduler.schedulers.background import BackgroundScheduler
from auth import receptionist_session, Auth

#import requests "for implementing queries from the fastAPI.py" 


# FASTAPI_URL = "http://127.0.0.1:8000"  "for implementing queries from the fastAPI.py" 


# # Mail Sending Using SMTP
# Old Code without 3 hrs email sending functionality

# def send_email(to_email, subject, body):
#     sender_email = "appointmentdoctor8@gmail.com"
#     sender_password = "jghrssnqsvuqnkto"

#     message = MIMEMultipart()
#     message["From"] = sender_email
#     message["To"] = to_email
#     message["Subject"] = subject

#     message.attach(MIMEText(body, "plain"))

#     try:
#         with smtplib.SMTP_SSL("smtp.gmail.com", 465) as smtp:
#             smtp.login(sender_email, sender_password)
#             smtp.sendmail(sender_email, to_email, message.as_string())
#         print(f"Email sent to {to_email}")
#     except Exception as e:
#         print(f"Error sending email to {to_email}: {e}")




# Function to send email
# New code with every 3 hrs email sending functionality
def send_email(to_email, subject, body):
    sender_email = "appointmentdoctor8@gmail.com"
    sender_password = "jghrssnqsvuqnkto"

    message = MIMEMultipart()
    message["From"] = sender_email
    message["To"] = to_email
    message["Subject"] = subject
    message.attach(MIMEText(body, "html"))

    try:
        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as smtp:
            smtp.login(sender_email, sender_password)
            smtp.sendmail(sender_email, to_email, message.as_string())
        print(f"✅ Reminder email sent to {to_email}")
    # except smtplib.SMTPRecipientsRefused as e:
    #     print(f"❌ Error sending email to {to_email}: {e}")
    #     return False  # Invalid email
    except Exception as e:
        print(f"❌ Error sending email to {to_email}: {e}")
    




# Fetch patient email from database
def get_patient_email(patient_id):
    
    #print("get_patient_email Called")

    conn = sqlite3.connect('hospital.db')
    cursor = conn.cursor()
    cursor.execute("SELECT email FROM patients WHERE id = ?", (patient_id,))
    result = cursor.fetchone()
    conn.close()
    return result[0] if result else None

# Fetch doctor email from database
def get_doctor_email(doctor_id):

    #print("get_doctor_email Called")

    conn = sqlite3.connect('hospital.db')
    cursor = conn.cursor()
    cursor.execute("SELECT email FROM doctors WHERE id = ?", (doctor_id,))
    result = cursor.fetchone()
    conn.close()
    return result[0] if result else None


# Fetch patient name from database
def get_patient_name(patient_id):
    """Fetch the patient's name based on the ID."""
    conn = sqlite3.connect('hospital.db')
    cursor = conn.cursor()
    cursor.execute("SELECT fname FROM patients WHERE id=?", (patient_id,))
    patient = cursor.fetchone()
    conn.close()
    return patient[0] if patient else None

# Fetch doctor name from database
def get_doctor_name(doctor_id):
    """Fetch the doctor's name based on the ID."""
    conn = sqlite3.connect('hospital.db')
    cursor = conn.cursor()
    cursor.execute("SELECT name FROM doctors WHERE id=?", (doctor_id,))
    doctor = cursor.fetchone()
    conn.close()
    return doctor[0] if doctor else None




# ---------------- Appointment Reminder Function ----------------
def send_reminder_emails():
    """Check appointments and send reminders 3 hours before, skipping already sent ones."""
    conn = sqlite3.connect("hospital.db")
    cursor = conn.cursor()

    print("📩 Running Reminder Email Function...")

    # Get current time and 3 hours later
    now = datetime.now()
    three_hours_later = now + timedelta(hours=3)

    now_str = now.strftime("%Y-%m-%d %H:%M")
    three_hours_later_str = three_hours_later.strftime("%Y-%m-%d %H:%M")

    print(f"🔎 Checking for appointments between {now_str} and {three_hours_later_str}")

    # Fetch appointments where reminder was NOT sent
    cursor.execute("""
    SELECT a.id, p.email, p.name, d.name, a.date, a.time
    FROM appointments a
    JOIN patients p ON a.patient_id = p.id
    JOIN doctors d ON a.doctor_id = d.id
    WHERE datetime(a.date || ' ' || a.time) 
    BETWEEN datetime(?) AND datetime(?)
    AND a.reminder_sent = 0
""", (now_str, three_hours_later_str))


    appointments = cursor.fetchall()

    if not appointments:
        print("⚠️ No new reminders to send.")
    else:
        for appointment_id, patient_email, patient_name, doctor_name, date, time in appointments:
            print(f"📧 Sending email to: {patient_email} (Patient: {patient_name})")

            subject = "⏳ Appointment Reminder"

            # 📌 HTML Email Template for Reminder
            body = f"""
            <html>
            <head>
                <style>
                    body {{ font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; }}
                    .container {{ max-width: 600px; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }}
                    h2 {{ color: #f39c12; }}
                    p {{ font-size: 16px; color: #333; }}
                    .footer {{ font-size: 14px; color: #777; text-align: center; margin-top: 20px; }}
                </style>
            </head>
            <body>
                <div class="container">
                    <h2>⏳ Appointment Reminder</h2>
                    <p>Dear <b>{patient_name}</b>,</p>
                    <p>This is a friendly reminder that you have an upcoming appointment with <b>Dr. {doctor_name}</b>.</p>
                    <p><strong>Date:</strong> {date}</p>
                    <p><strong>Time:</strong> {time}</p>
                    <p>Please ensure you arrive on time.</p>
                    <p>Thank you!</p>
                    <div class="footer">📧 This is an automated message, please do not reply.</div>
                </div>
            </body>
            </html>
            """

            if patient_email:
                send_email(patient_email, subject, body)

                # ✅ Mark reminder as sent in the database
                cursor.execute("UPDATE appointments SET reminder_sent = 1 WHERE id = ?", (appointment_id,))
                conn.commit()

    conn.close()




# ---------------- Background Scheduler (Runs Every 1 Minute) ----------------
def start_scheduler():
    scheduler = BackgroundScheduler()
    scheduler.add_job(send_reminder_emails, "interval", minutes=1)
    scheduler.start()
    print("✅ Reminder email scheduler started!")
    




# Function to fetch patients

def fetch_patients():

    print("fetch_patients Called")

    conn = sqlite3.connect('hospital.db')
    cursor = conn.cursor()
    cursor.execute("SELECT id, fname FROM patients")
    patients = cursor.fetchall()
    conn.close()
    return patients



""" 
    We can run the receptionist Dashboard and all other files without the need to write database queries in this file
    We can import the database queries from the fastAPI.py files and then implement them here directly

    📌 How This Helps Your Application
        1️⃣ Makes Code Modular → If you ever want to build a web or mobile app, you won’t need to change the business logic.
        2️⃣ Reduces Database Load → The API can handle caching, reducing unnecessary queries.
        3️⃣ Easier Debugging & Testing → APIs can be tested separately with Postman before integrating with the GUI.
        4️⃣ Future-Proofing → If you want to migrate from SQLite to MySQL/PostgreSQL, you only need to update the FastAPI layer, not the GUI.
        5️⃣ Multi-Platform Support → This setup allows other applications (mobile, web, admin dashboards, etc.) to also use the API.

        The below fetch_patients() function is an example of Integrating FastAPI with receptionist_dashboard.py Benefit the Application

"""
# def fetch_patients():
#     try:
#         response = requests.get(f"{FASTAPI_URL}/get_patients")
#         if response.status_code == 200:
#             patients = response.json()
#             if isinstance(patients, list) and all("id" in p and "name" in p for p in patients):
#                 return [(p["id"], p["name"]) for p in patients]  # Return as a list of tuples
#         return []  # Return empty list if API fails or data format is incorrect
#     except requests.exceptions.RequestException as e:
#         print(f"Error fetching patients: {e}")
#         return []  # Return empty list if request fails





# Function to fetch available doctors
def fetch_available_doctors():

    print("fetch_available_doctors Called")

    conn = sqlite3.connect('hospital.db')
    cursor = conn.cursor()
    cursor.execute("SELECT id, name, specialization FROM doctors WHERE availability = 'Available'")
    doctors = cursor.fetchall()
    conn.close()
    return doctors



# Function to fetch available slots for a doctor
# def fetch_available_slots(doctor_id, date):

#     print("fetch_available_slots Called")

    
#     #all_slots=["08:00 AM", "08:15 AM", "08:30 AM", "08:45 AM", "09:00 AM", "09:30 AM","09:45 AM","10:00 AM","10:15 AM","10:30 AM","10:45 AM","11:00 AM","11:15 AM","11:30 AM","11:45 AM","01:00 PM", "01:15 PM", "01:30 PM", "01:45 PM", "02:00 PM", "02:15 PM", "02:30 PM", "02:45 PM", "03:00 PM", "03:15 PM", "03:30 PM", "03:45 PM", "04:00 PM", "04:15 PM", "04:30 PM", "04:45 PM", "05:00 PM"]
#     all_slots=["08:00", "08:15", "08:30", "08:45", "09:00", "09:30","09:45","10:00","10:15","10:30","10:45","11:00","11:15","11:30","11:45","01:00", "01:15", "01:30", "01:45", "02:00", "02:15", "02:30", "02:45", "03:00", "03:15", "03:30", "03:45", "04:00", "04:15", "04:30", "04:45", "05:00"]

#     available_slots = [slot for slot in all_slots if is_slot_available(doctor_id, date, slot)]
#     return available_slots


def fetch_available_slots(doctor_id, date):
    """Fetch available slots by removing already booked ones."""
    
    print(f"Fetching available slots for Doctor {doctor_id} on {date}")

    all_slots = ["08:00", "08:15", "08:30", "08:45", "09:00", "09:15", "09:30", "09:45",
                 "10:00", "10:15", "10:30", "10:45", "11:00", "11:15", "11:30", "11:45",
                 "12:00", "12:15", "12:30", "12:45",
                 "13:00", "13:15", "13:30", "13:45",
                 "14:00", "14:15", "14:30", "14:45",
                 "15:00", "15:15", "15:30", "15:45",
                 "16:00", "16:15", "16:30", "16:45",
                 "17:00"]

    available_slots = [slot for slot in all_slots if is_slot_available(doctor_id, date, slot)]
    
    print("Available Slots:", available_slots)  # Debugging
    return available_slots




# Function to check if a slot is available
# def is_slot_available(doctor_id, date, time):

#     print("is_slot_available Called")

#     conn = sqlite3.connect('hospital.db')
#     cursor = conn.cursor()
#     cursor.execute("SELECT COUNT(*) FROM appointments WHERE doctor_id = ? AND date = ? AND time = ?", 
#                    (doctor_id, date, time))
#     count = cursor.fetchone()[0]
#     conn.close()
#     return count == 0


def is_slot_available(doctor_id, date, time):
    conn = sqlite3.connect('hospital.db')
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) FROM appointments WHERE doctor_id = ? AND date = ? AND time = ?", 
                   (doctor_id, date, time))
    
    count = cursor.fetchone()[0]
    
    print(f"Checking slot availability for Doctor {doctor_id} on {date} at {time} → Booked Count: {count}")
    
    conn.close()
    return count == 0  # If count > 0, the slot is booked








# Function to convert 12-hour time to 24-hour format
def convert_time_to_24hr(time_str):
    """Converts time from 12-hour format (HH:MM AM/PM) to 24-hour format (HH:MM)."""
    return datetime.strptime(time_str, "%I:%M %p").strftime("%H:%M")

# Function to convert date to correct format
def convert_date_to_YYYYMMDD(date_str):
    """Converts date from MM/DD/YY or MM/DD/YYYY to YYYY-MM-DD format."""
    try:
        return datetime.strptime(date_str, "%m/%d/%y").strftime("%Y-%m-%d")
    except ValueError:
        return datetime.strptime(date_str, "%m/%d/%Y").strftime("%Y-%m-%d")



def convert_time_to_12hr(time_str):
    """Converts time from 24-hour format (HH:MM) to 12-hour format (HH:MM AM/PM)."""
    return datetime.strptime(time_str, "%H:%M").strftime("%I:%M %p")


def convert_date_to_DDMMYYYY(date_str):
    """Converts date from YYYY-MM-DD to DD/MM/YYYY format."""
    return datetime.strptime(date_str, "%Y-%m-%d").strftime("%d/%m/%Y")


# # Function to book an appointment
# def book_appointment(patient_id, doctor_id, date, time, illness):
#     if not patient_id or not doctor_id or not date or not time or not illness:
#         messagebox.showerror("Error", "All fields are required!")
#         return

#     conn = sqlite3.connect('hospital.db')
#     cursor = conn.cursor()
#     cursor.execute("INSERT INTO appointments (patient_id, doctor_id, date, time, illness) VALUES (?, ?, ?, ?, ?)",
#                    (patient_id, doctor_id, date, time, illness))
#     conn.commit()
#     conn.close()

#     # Get Patient and Doctor name  
#     patient_name = get_patient_name(patient_id)
#     doctor_name = get_doctor_name(doctor_id)


#     # Send email notifications
#     patient_email = get_patient_email(patient_id)
#     doctor_email = get_doctor_email(doctor_id)

#     subject = "Appointment Confirmation"
#     patient_body = f"Dear Patient,\n\nYour appointment has been booked successfully!\nDate: {date}\nTime: {time}\nDoctor Name: {doctor_name}\n\nThank you!"
#     doctor_body = f"Dear Doctor,\n\nA new appointment has been booked.\nPatient Name: {patient_name}\nDate: {date}\nTime: {time}\nIllness: {illness}\n\nThank you!"

#     if patient_email:
#         send_email(patient_email, subject, patient_body)
#     if doctor_email:
#         send_email(doctor_email, subject, doctor_body)

#     messagebox.showinfo("Success", "Appointment booked successfully!")


# Function to book an appointment
def book_appointment(patient_id, doctor_id, date, time, illness):
    if not patient_id or not doctor_id or not date or not time or not illness:
        messagebox.showerror("Error", "All fields are required!")
        return

    print("book_appointment Called")
    
    # Convert date and time to correct format
    converted_date = convert_date_to_YYYYMMDD(date)
    converted_time = convert_time_to_24hr(time)  # Convert to 24-hour format

    conn = sqlite3.connect("hospital.db")
    cursor = conn.cursor()
    cursor.execute("INSERT INTO appointments (patient_id, doctor_id, date, time, illness) VALUES (?, ?, ?, ?, ?)",
                   (patient_id, doctor_id, converted_date, converted_time, illness))
    conn.commit()
    conn.close()

    # Get Patient and Doctor name  
    patient_name = get_patient_name(patient_id)
    doctor_name = get_doctor_name(doctor_id)

    # Send email notifications
    patient_email = get_patient_email(patient_id)
    doctor_email = get_doctor_email(doctor_id)

    subject = "Appointment Confirmation"
    # patient_body = f"Dear Patient,\n\nYour appointment has been booked successfully!\nDate: {converted_date}\nTime: {time} (12-hour format)\nDoctor Name: {doctor_name}\n\nThank you!"
    # 📌 HTML Email Template for Patient
    patient_body = f"""
    <html>
    <head>
        <style>
            body {{ font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; }}
            .container {{ max-width: 600px; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }}
            h2 {{ color: #2c3e50; }}
            p {{ font-size: 16px; color: #333; }}
            .footer {{ font-size: 14px; color: #777; text-align: center; margin-top: 20px; }}
        </style>
    </head>
    <body>
        <div class="container">
            <h2>✅ Appointment Confirmation</h2>
            <p>Dear <b>{patient_name}</b>,</p>
            <p>Your appointment has been successfully booked!</p>
            <p><b>Date:</b> {converted_date}</p>
            <p><b>Time:</b> {time} </p>
            <p><b>Doctor:</b> Dr. {doctor_name}</p>
            <p>Thank you for choosing our service!</p>
            <div class="footer">📧 This is an automated message, please do not reply.</div>
        </div>
    </body>
    </html>
    """
    
    
    # doctor_body = f"Dear Doctor,\n\nA new appointment has been booked.\nPatient Name: {patient_name}\nDate: {converted_date}\nTime: {time} (12-hour format)\nIllness: {illness}\n\nThank you!"

     # 📌 HTML Email Template for Doctor
    doctor_body = f"""
    <html>
    <head>
        <style>
            body {{ font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; }}
            .container {{ max-width: 600px; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }}
            h2 {{ color: #d35400; }}
            p {{ font-size: 16px; color: #333; }}
            .footer {{ font-size: 14px; color: #777; text-align: center; margin-top: 20px; }}
        </style>
    </head>
    <body>
        <div class="container">
            <h2>📅 New Appointment Scheduled</h2>
            <p>Dear Dr. <b>{doctor_name}</b>,</p>
            <p>A new appointment has been scheduled:</p>
            <p><b>Patient Name:</b> {patient_name}</p>
            <p><b>Date:</b> {converted_date}</p>
            <p><b>Time:</b> {time} </p>
            <p><b>Illness:</b> {illness}</p>
            <p>Please review your schedule accordingly.</p>
            <div class="footer">📧 This is an automated message, please do not reply.</div>
        </div>
    </body>
    </html>
    """


    if patient_email:
        send_email(patient_email, subject, patient_body)
    if doctor_email:
        send_email(doctor_email, subject, doctor_body)

    
    messagebox.showinfo("Success", "Appointment booked successfully!")


# Function to edit an appointment
def edit_appointment(appt_id, doctor_id, new_date, new_time):
    
    """Edit an appointment and notify patient & doctor via email."""

    # Check if the new slot is available
    if not is_slot_available(doctor_id, new_date, new_time):
        messagebox.showerror("Error", "This slot is already booked!")
        return
    
    print("edit_appointment Called")
    
    conn = sqlite3.connect('hospital.db')
    cursor = conn.cursor()

    # Convert date and time to correct format
    converted_date = convert_date_to_YYYYMMDD(new_date)
    converted_time = convert_time_to_24hr(new_time)  # Convert to 24-hour format

    # Fetch patient ID before updating
    cursor.execute("SELECT patient_id FROM appointments WHERE id = ?", (appt_id,))
    result = cursor.fetchone()


    if not result:
        messagebox.showerror("Error", "Appointment not found!")
        conn.close()
        return

    patient_id = result[0]



    cursor.execute("UPDATE appointments SET date = ?, time = ? WHERE id = ?", (converted_date, converted_time, appt_id))
    conn.commit()
    conn.close()


    # Get Patient and Doctor name  
    patient_name = get_patient_name(patient_id)
    doctor_name = get_doctor_name(doctor_id)


    # Fetch emails of Patient and Doctor
    patient_email = get_patient_email(patient_id)
    doctor_email = get_doctor_email(doctor_id)



    subject = "Appointment Updated"
    #patient_body = f"Dear Patient,\n\nYour appointment has been updated.\nNew Date: {new_date}\nNew Time: {new_time}\nDoctor Name: {doctor_name}\n\nThank you!"
    #doctor_body = f"Dear Doctor,\n\nAn appointment has been updated.\nPatient Name: {patient_name}\nNew Date: {new_date}\nNew Time: {new_time}\n\nThank you!"

    # 📌 HTML Email Template for Patient
    patient_body = f"""
    <html>
    <head>
        <style>
            body {{ font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; }}
            .container {{ max-width: 600px; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }}
            h2 {{ color: #e67e22; }}
            p {{ font-size: 16px; color: #333; }}
            .footer {{ font-size: 14px; color: #777; text-align: center; margin-top: 20px; }}
        </style>
    </head>
    <body>
        <div class="container">
            <h2>⚡ Appointment Updated</h2>
            <p>Dear <b>{patient_name}</b>,</p>
            <p>Your appointment has been updated.</p>
            <p><b>New Date:</b> {converted_date}</p>
            <p><b>New Time:</b> {new_time} </p>
            <p><b>Doctor:</b> Dr. {doctor_name}</p>
            <p>Thank you for choosing our service!</p>
            <div class="footer">📧 This is an automated message, please do not reply.</div>
        </div>
    </body>
    </html>
    """

    # 📌 HTML Email Template for Doctor
    doctor_body = f"""
    <html>
    <head>
        <style>
            body {{ font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; }}
            .container {{ max-width: 600px; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }}
            h2 {{ color: #2980b9; }}
            p {{ font-size: 16px; color: #333; }}
            .footer {{ font-size: 14px; color: #777; text-align: center; margin-top: 20px; }}
        </style>
    </head>
    <body>
        <div class="container">
            <h2>📅 Appointment Updated</h2>
            <p>Dear Dr. <b>{doctor_name}</b>,</p>
            <p>An appointment has been updated.</p>
            <p><b>Patient Name:</b> {patient_name}</p>
            <p><b>New Date:</b> {converted_date}</p>
            <p><b>New Time:</b> {new_time}</p>
            <p>Please review your schedule accordingly.</p>
            <div class="footer">📧 This is an automated message, please do not reply.</div>
        </div>
    </body>
    </html>
    """

    if patient_email:
        send_email(patient_email, subject, patient_body)
    if doctor_email:
        send_email(doctor_email, subject, doctor_body)

    
    messagebox.showinfo("Success", "Appointment updated successfully!")



# Function to cancel an appointment
def cancel_appointment(appt_id):

    """Function to Cancel Appointment and send emails"""

    print("cancel_appointment Called")

    conn = sqlite3.connect('hospital.db')
    cursor = conn.cursor()

    # Fetch Patient and Doctor ID before deleting
    cursor.execute("SELECT patient_id, doctor_id FROM appointments WHERE id = ?", (appt_id,))
    result = cursor.fetchone()

    if not result:
        messagebox.showerror("Error", f"Appointment with ID {appt_id} not found!")
        return
    
    patient_id,doctor_id = result

    cursor.execute("DELETE FROM appointments WHERE id = ?", (appt_id,))
    conn.commit()
    conn.close()




    # Fetch emails of Patient and Doctor
    patient_email = get_patient_email(patient_id)
    doctor_email = get_doctor_email(doctor_id)

    # Fetch Patient and Doctor Names
    patient_name = get_patient_name(patient_id) or "Patient"
    doctor_name = get_doctor_name(doctor_id) or "Doctor"


    subject = "Appointment Cancelled"

    #patient_body = f"Dear {patient_name},\n\nYour appointment with Dr. {doctor_name} has been cancelled.\n\nIf this was a mistake, please schedule a new appointment.\n\nThank you!"
    #doctor_body = f"Dear {doctor_name},\n\nThe appointment with {patient_name} has been cancelled.\n\nIf you have any concerns, please contact the hospital administration.\n\nThank you!"


    # 📌 HTML Email Template for Patient
    patient_body = f"""
    <html>
    <head>
        <style>
            body {{ font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; }}
            .container {{ max-width: 600px; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }}
            h2 {{ color: #e74c3c; }}
            p {{ font-size: 16px; color: #333; }}
            .footer {{ font-size: 14px; color: #777; text-align: center; margin-top: 20px; }}
        </style>
    </head>
    <body>
        <div class="container">
            <h2>❌ Appointment Cancelled</h2>
            <p>Dear <b>{patient_name}</b>,</p>
            <p>Your appointment with Dr. <b>{doctor_name}</b> has been cancelled.</p>
            <p>If this was a mistake, please schedule a new appointment.</p>
            <p>We apologize for any inconvenience.</p>
            <div class="footer">📧 This is an automated message, please do not reply.</div>
        </div>
    </body>
    </html>
    """

    # 📌 HTML Email Template for Doctor
    doctor_body = f"""
    <html>
    <head>
        <style>
            body {{ font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; }}
            .container {{ max-width: 600px; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }}
            h2 {{ color: #c0392b; }}
            p {{ font-size: 16px; color: #333; }}
            .footer {{ font-size: 14px; color: #777; text-align: center; margin-top: 20px; }}
        </style>
    </head>
    <body>
        <div class="container">
            <h2>🚨 Appointment Cancelled</h2>
            <p>Dear Dr. <b>{doctor_name}</b>,</p>
            <p>The appointment with <b>{patient_name}</b> has been cancelled.</p>
            <p>If you have any concerns, please contact the hospital administration.</p>
            <div class="footer">📧 This is an automated message, please do not reply.</div>
        </div>
    </body>
    </html>
    """

    # Send Emails
    if patient_email:
        send_email(patient_email, subject, patient_body)
    else:
        print(f"Warning: No email found for patient ID {patient_id}")  # Log missing email

    if doctor_email:
        send_email(doctor_email, subject, doctor_body)
    else:
        print(f"Warning: No email found for doctor ID {doctor_id}")  # Log missing


    messagebox.showinfo("Success", "Appointment canceled successfully!")



# Function to generate time slots based on selected shift
def generate_time_slots(shift):

    print("generate_time_slots Called")


    morning_slots = ["08:00 AM", "08:15 AM", "08:30 AM", "08:45 AM", "09:00 AM", "09:30 AM","09:45 AM","10:00 AM","10:15 AM","10:30 AM","10:45 AM","11:00 AM","11:15 AM","11:30 AM","11:45 AM"]
    afternoon_slots = ["01:00 PM", "01:15 PM", "01:30 PM", "01:45 PM", "02:00 PM", "02:15 PM", "02:30 PM", "02:45 PM", "03:00 PM", "03:15 PM", "03:30 PM", "03:45 PM", "04:00 PM", "04:15 PM", "04:30 PM", "04:45 PM", "05:00 PM"]
    

    if shift == "Morning":
        return morning_slots
    elif shift == "Afternoon":
        return afternoon_slots
    return []

# Appointment Booking Form
def open_booking_form():

    #global root

    if not receptionist_session.get('logged_in'):
        messagebox.showerror("Access Denied", "You must be logged in to access this page.")
        return
    
    print("open_booking_form Called")
    

    booking_window = tk.Toplevel()
    booking_window.title("Book Appointment")
    booking_window.geometry("400x450")

    tk.Label(booking_window, text="Select Patient:").pack()
    patients = fetch_patients()
    patient_var = tk.StringVar()
    patient_dropdown = ttk.Combobox(booking_window, textvariable=patient_var, values=[f"{p[0]} - {p[1]}" for p in patients])
    patient_dropdown.pack()

    tk.Label(booking_window, text="Select Doctor:").pack()
    doctors = fetch_available_doctors()
    doctor_var = tk.StringVar()
    doctor_dropdown = ttk.Combobox(booking_window, textvariable=doctor_var, values=[f"{d[0]} - Dr. {d[1]}" for d in doctors])
    doctor_dropdown.pack()

    tk.Label(booking_window, text="Select Date:").pack()
    date_entry = DateEntry(booking_window)
    date_entry.pack()

    tk.Label(booking_window, text="Select Shift:").pack()

    time_var = tk.StringVar()
    time_dropdown = ttk.Combobox(booking_window, textvariable=time_var)
    time_dropdown.pack()

    def update_time_slots(shift):
        available_slots = generate_time_slots(shift)
        time_dropdown["values"] = available_slots
        if available_slots:
            time_var.set(available_slots[0])  # Auto-select the first available slot

    # Buttons for shifts
    tk.Button(booking_window, text="Morning (8 AM - 12 PM)", command=lambda: update_time_slots("Morning")).pack(pady=2)
    tk.Button(booking_window, text="Afternoon (1 PM - 5 PM)", command=lambda: update_time_slots("Afternoon")).pack(pady=2)
    #tk.Button(booking_window, text="Evening (4 PM - 8 PM)", command=lambda: update_time_slots("Evening")).pack(pady=2)

    tk.Label(booking_window, text="Illness / Medical Concern:").pack()
    illness_entry = tk.Entry(booking_window)
    illness_entry.pack()

    def submit_appointment():
        selected_patient = patient_var.get().split(" - ")[0] if patient_var.get() else None
        selected_doctor = doctor_var.get().split(" - ")[0] if doctor_var.get() else None
        book_appointment(selected_patient, selected_doctor, date_entry.get(), time_var.get(), illness_entry.get())
        root.destroy()
        
    
    

    tk.Button(booking_window, text="Book Appointment", command=submit_appointment).pack(pady=10)
    
    
    




# # Function to register a new patient
# def register_patient(name, age, phone, email, patient_dropdown):
#     if not name or not age or not phone or not email:
#         messagebox.showerror("Error", "All fields are required!")
#         return
    
#     print("register_patient Called")


#     conn = sqlite3.connect('hospital.db')
#     cursor = conn.cursor()
#     cursor.execute("INSERT INTO patients (name, age, phone, email) VALUES (?, ?, ?, ?)", 
#                    (name, age, phone, email))
#     conn.commit()
#     conn.close()

#     messagebox.showinfo("Success", "Patient registered successfully!")

#     # Refresh patient dropdown only if it's not None
#     if patient_dropdown:
#         patients = fetch_patients()
#         patient_dropdown["values"] = [f"{p[0]} - {p[1]}" for p in patients]

#     # # Refresh patient dropdown
#     # patients = fetch_patients()
    
#     # if patients:  # Check if fetch_patients() returned a valid list
#     #     patient_dropdown["values"] = [f"{p[0]} - {p[1]}" for p in patients]
#     # else:
#     #     patient_dropdown["values"] = []  # Set to an empty list to avoid errors



# Dictionary to store patient data across forms
patient_data = {}

# Function to move to the next form
def show_form(current_form, next_form):
    current_form.pack_forget()
    next_form.pack()

# Function to submit patient data to the database
def register_patient():
    conn = sqlite3.connect('hospital.db')
    cursor = conn.cursor()

    # Insert into patients table
    cursor.execute(
    '''INSERT INTO patients 
       (fname, lname, dob, gender, married, occupation, email, phone_number, address, city, state, zip, country,
        emergency_name, emergency_number, emergency_relation, height, weight, blood_pressure,
        blood_group, allergies, current_medications, medical_conditions, surgical_history, family_medical_history, 
        generic_testing, tobacco_use, alcohol_consumption, physical_activity, diet, sleep_duration) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)''',
    (
        patient_data["fname"], patient_data["lname"], patient_data["dob"], patient_data["gender"],
        patient_data.get("marital_status", ""), patient_data.get("occupation", ""),
        patient_data["email"], patient_data["phone"],
        patient_data["address"], patient_data["city"], patient_data["state"], patient_data["zip_code"], patient_data["country"],
        patient_data.get("emergency_contact_name", ""), patient_data.get("emergency_contact_number", ""), patient_data.get("emergency_contact_relation", ""),
        patient_data.get("height", ""), patient_data.get("weight", ""), patient_data.get("blood_pressure", ""),
        patient_data.get("blood_group", ""), patient_data.get("allergies", ""), patient_data.get("current_medication", ""),
        ",".join(patient_data.get("medical_conditions", [])), patient_data["surgical_history"], patient_data.get("family_medical_history", ""),
        patient_data.get("genetic_testing", ""), patient_data.get("tobacco_use", ""), patient_data.get("alcohol_consumption", ""),
        patient_data.get("physical_activity", ""), patient_data.get("diet", ""), patient_data.get("sleep_duration", "")
    )
)
    

    
    email=patient_data['email']
    print(patient_data)

    subject = "⏳ Registering on Doctor Appointment"

    body="Welcome to Doctor Appointment"
    if not send_email(email,subject,body):
        return
    
    send_email(email,subject,body)


    conn.commit()
    conn.close()
    
    messagebox.showinfo("Success", "Patient Registered Successfully!")
    patient_window.destroy()  # Close window after registration


# # Patient Registration Form
# def open_patient_registration(patient_dropdown=None):
#     if not receptionist_session.get('logged_in'):
#         messagebox.showerror("Access Denied", "You must be logged in to access this page.")
#         return
    
#     print("open_patient_registration Called")


#     reg_window = tk.Toplevel()
#     reg_window.title("Register New Patient")
#     reg_window.geometry("400x350")

#     tk.Label(reg_window, text="Register New Patient", font=("Arial", 14, "bold")).pack(pady=10)

#     tk.Label(reg_window, text="Patient Name:").pack()
#     name_entry = tk.Entry(reg_window)
#     name_entry.pack()

#     tk.Label(reg_window, text="Age:").pack()
#     age_entry = tk.Entry(reg_window)
#     age_entry.pack()

#     tk.Label(reg_window, text="Phone Number:").pack()
#     phone_entry = tk.Entry(reg_window)
#     phone_entry.pack()

#     tk.Label(reg_window, text="Email:").pack()
#     email_entry = tk.Entry(reg_window)
#     email_entry.pack()

#     def submit_patient():
#         register_patient(name_entry.get(), age_entry.get(), phone_entry.get(), email_entry.get(), patient_dropdown)
#         reg_window.destroy()  # Close only the registration window
        
#         # subprocess.Popen(["python", "receptionist_dashboard.py"])  # Open the main GUI
        

#     tk.Button(reg_window, text="Register", command=submit_patient).pack(pady=10)
    
# Function to open the multi-step patient registration form
def open_patient_registration():
    
    global patient_window
    
    patient_window = tk.Toplevel()
    patient_window.title("Patient Registration")
    patient_window.geometry("500x500")

    # **Form 1: Demographics**
    form1 = tk.Frame(patient_window)
    
    tk.Label(form1, text="Demographics", font=("Arial", 14, "bold")).pack(pady=10)
    tk.Label(form1, text="First Name:").pack()
    first_name = tk.Entry(form1)
    first_name.pack()

    tk.Label(form1, text="Last Name:").pack()
    last_name = tk.Entry(form1)
    last_name.pack()

    # tk.Label(form1, text="Age:").pack()  # ✅ Add Age field
    # age = tk.Entry(form1)  
    # age.pack()

    tk.Label(form1, text="Date of Birth:").pack()
    dob = tk.Entry(form1)
    dob.pack()

    tk.Label(form1, text="Gender:").pack()
    gender = ttk.Combobox(form1, values=["Male", "Female", "Other"])
    gender.pack()

    tk.Label(form1, text="Marital Status (Optional):").pack()
    marital_status = ttk.Combobox(form1, values=["Single", "Married", "Divorced", "Widowed"])
    marital_status.pack()

    tk.Label(form1, text="Occupation (Optional):").pack()
    occupation = tk.Entry(form1)
    occupation.pack()

    # ✅ Update patient_data to include "age"
    tk.Button(form1, text="Next", command=lambda: (
        patient_data.update({
            "fname": first_name.get(),
            "lname": last_name.get(),  
            "dob": dob.get(), 
            "gender": gender.get(), 
            "married": marital_status.get(), 
            "occupation": occupation.get()
        }),
        show_form(form1, form2)
    )).pack(pady=10)

    # **Form 2: Contact Info**
    form2 = tk.Frame(patient_window)

    tk.Label(form2, text="Contact Information", font=("Arial", 14, "bold")).pack(pady=10)
    tk.Label(form2, text="Email:").pack()
    email = tk.Entry(form2)
    email.pack()

    tk.Label(form2, text="Phone Number:").pack()
    phone = tk.Entry(form2)
    phone.pack()

    tk.Label(form2, text="Address:").pack()
    address = tk.Entry(form2)
    address.pack()

    tk.Label(form2, text="City:").pack()
    city = tk.Entry(form2)
    city.pack()

    tk.Label(form2, text="State:").pack()
    state = tk.Entry(form2)
    state.pack()

    tk.Label(form2, text="Zip Code:").pack()
    zip_code = tk.Entry(form2)
    zip_code.pack()

    tk.Label(form2, text="Country:").pack()
    country = tk.Entry(form2)
    country.pack()

    tk.Label(form2, text="Emergency Contact Name:").pack()
    emergency_contact_Name = tk.Entry(form2)
    emergency_contact_Name.pack()

    tk.Label(form2, text="Emergency Contact Number:").pack()
    emergency_contact_Number = tk.Entry(form2)
    emergency_contact_Number.pack()

    tk.Label(form2, text="Emergency Contact Relation:").pack()
    emergency_contact_Relation = tk.Entry(form2)
    emergency_contact_Relation.pack()

    tk.Button(form2, text="Next", command=lambda: (
        patient_data.update({
                            "email": email.get(),
                            "phone": phone.get(),
                            "address": address.get(),
                            "city": city.get(),
                            "state": state.get(),
                            "zip_code": zip_code.get(),
                            "country": country.get(),
                            "emergency_contact_name": emergency_contact_Name.get(),   # ✅ Match this key
                            "emergency_contact_number": emergency_contact_Number.get(),
                            "emergency_contact_relation": emergency_contact_Relation.get()  # ✅ Match this key
                        }),
        show_form(form2, form3)
    )).pack(pady=10)



    # **Form 3: Vital Info**
    form3 = tk.Frame(patient_window)

    tk.Label(form3, text="Vital Information", font=("Arial", 14, "bold")).pack(pady=10)

    tk.Label(form3, text="Height:").pack()
    height = tk.Entry(form3)
    height.pack()

    tk.Label(form3, text="Weight:").pack()
    weight = tk.Entry(form3)
    weight.pack()

    tk.Label(form3, text="Blood Pressure:").pack()
    blood_pressure = tk.Entry(form3)
    blood_pressure.pack()

    tk.Label(form3, text="Blood Group:").pack()
    blood_group = tk.Entry(form3)
    blood_group.pack()

    tk.Label(form3, text=" Current Medications:").pack()
    current_medications = tk.Entry(form3)
    current_medications.pack()

    tk.Label(form3, text="Allergies (Yes/No/Unknown):").pack()
    allergies = ttk.Combobox(form3, values=["Yes", "No", "Unknown"])
    allergies.pack()

    tk.Button(form3, text="Next", command=lambda: (
        patient_data.update({"height":height.get(),
                             "weight":weight.get(),
                             "blood_pressure":blood_pressure.get(),
                             "blood_group":blood_group.get(),
                             "current_medications":current_medications.get(),
                             "allergies":allergies.get()}),
        show_form(form3, form4)
    )).pack(pady=10)



    # **Form 4: Medical History and Genetic Info**
    form4 = tk.Frame(patient_window)

    tk.Label(form4, text="Medical History", font=("Arial", 14, "bold")).pack(pady=10)
    
    tk.Label(form4, text=" Any Medical Conditions:").pack()
    medical_conditions = tk.Entry(form4)
    medical_conditions.pack()

    tk.Label(form4, text="Surgical History (Yes/No):").pack()
    surgical_history = ttk.Combobox(form4, values=["Yes", "No"])
    surgical_history.pack()

    tk.Label(form4, text=" Family Medical History:").pack()
    family_medical_history = tk.Entry(form4)
    family_medical_history.pack()

    tk.Label(form4, text=" Generic Testing:").pack()
    generic_testing = tk.Entry(form4)
    generic_testing.pack()

    tk.Button(form4, text="Next", command=lambda: (
        patient_data.update({"medical_conditions":medical_conditions.get().split(","),
                             "surgical_history":surgical_history.get(),
                             "family_medical_history":family_medical_history.get(),
                             "generic_testing":generic_testing.get()}),
        show_form(form4, form5)
    )).pack(pady=10)    

    # **Form 5: Health Habits and Lifestyle**
    form5 = tk.Frame(patient_window)

    tk.Label(form5, text="Health Habits", font=("Arial", 14, "bold")).pack(pady=10)
    tk.Label(form5, text="Tobacco Use (Never, Former, Current):").pack()
    tobacco_use = ttk.Combobox(form5, values=["Never", "Former", "Current"])
    tobacco_use.pack()

    tk.Label(form5, text="Alcohol Consumption (Never, Occassional, Moderate,Heavy):").pack()
    alcohol_consumption = ttk.Combobox(form5, values=["Never", "Former", "Current","Heavy"])
    alcohol_consumption.pack()

    tk.Label(form5, text=" Physical Activity:").pack()
    physical_activity = tk.Entry(form5)
    physical_activity.pack()

    tk.Label(form5, text=" Diet:").pack()
    diet = tk.Entry(form5)
    diet.pack()

    tk.Label(form5, text=" Sleep Duration:").pack()
    sleep_duration = tk.Entry(form5)
    sleep_duration.pack()




    tk.Button(form5, text="Submit", command=lambda: (
                patient_data.update({
                    "tobacco_use": tobacco_use.get(),
                    "alcohol_consumption": alcohol_consumption.get(),
                    "physical_activity": physical_activity.get(),
                    "diet": diet.get(),
                    "sleep_duration": sleep_duration.get()  # ✅ Fixed reference
                }),
                register_patient()
            )).pack(pady=10)

    # Show first form
    form1.pack()



# Function to manage appointments
def open_appointment_list():

    if not receptionist_session.get('logged_in'):
        messagebox.showerror("Access Denied", "You must be logged in to access this page.")
        return
    
    print("open_appointment_list Called")


    appointments_window = tk.Toplevel()
    appointments_window.title("Appointments List")
    appointments_window.geometry("800x600")

    tk.Label(appointments_window, text="All Appointments", font=("Arial", 14, "bold")).pack(pady=10)

    conn = sqlite3.connect('hospital.db')
    cursor = conn.cursor()
    cursor.execute("SELECT a.id, p.name, d.name, a.date, a.time ,a.illness FROM appointments a JOIN patients p ON a.patient_id = p.id JOIN doctors d ON a.doctor_id = d.id")
    
    # To order by date and time
    # cursor.execute("""
    #     SELECT a.id,p.name AS patient_name, d.name AS doctor_name, a.date,a.time,a.illness
    #     FROM appointments a
    #     JOIN patients p ON a.patient_id = p.id
    #     JOIN doctors d ON a.doctor_id = d.id
    #     ORDER BY a.date, a.time    
    # """)
    appointments = cursor.fetchall()
    conn.close()

    tree = ttk.Treeview(appointments_window, columns=("ID", "Patient", "Doctor", "Date", "Time","Illness"), show="headings")
    tree.heading("ID", text="ID")
    tree.heading("Patient", text="Patient")
    tree.heading("Doctor", text="Doctor")
    tree.heading("Date", text="Date")
    tree.heading("Time", text="Time")
    tree.heading("Illness", text="Illness")




    # for appt in appointments:
    #     tree.insert("", "end", values=appt)

    for appt in appointments:
        appt_id, patient_name, doctor_name, date, time, illness = appt
        formatted_date = convert_date_to_DDMMYYYY(date)
        formatted_time = convert_time_to_12hr(time)
        tree.insert("", "end", values=(appt_id, patient_name, doctor_name, formatted_date, formatted_time, illness))


    tree.pack(expand=True, fill="both")

    def edit_selected():
        selected_item = tree.selection()
        if not selected_item:
            messagebox.showerror("Error", "Please select an appointment to edit")
            return
        appt_values = tree.item(selected_item)['values']
        appt_id = appt_values[0]  # Appointment ID
        doctor_name = appt_values[2]  # Doctor's name (column 3)
        
        # Fetch doctor_id from database using doctor_name
        conn = sqlite3.connect('hospital.db')
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM doctors WHERE name = ?", (doctor_name,))
        result = cursor.fetchone()
        conn.close()

        if result:
            doctor_id = result[0]  # Extract doctor_id
            edit_appointment(appt_id, doctor_id, date_entry.get(), time_var.get())
        else:
            messagebox.showerror("Error", "Doctor not found in the database.")

    def cancel_selected():
        selected_item = tree.selection()
        if not selected_item:
            messagebox.showerror("Error", "Please select an appointment to cancel")
            return
        appt_id = tree.item(selected_item)['values'][0]
        cancel_appointment(appt_id)
        tree.delete(selected_item)

    # Label for date selection
    tk.Label(appointments_window, text="Select New Date:").pack()
    date_entry = DateEntry(appointments_window)
    date_entry.pack()

    # Label for time selection
    tk.Label(appointments_window, text="Select Shift:").pack()

    time_var = tk.StringVar()
    time_dropdown = ttk.Combobox(appointments_window, textvariable=time_var)
    time_dropdown.pack()

    def update_time_slots(shift):
        available_slots = generate_time_slots(shift)
        time_dropdown["values"] = available_slots
        if available_slots:
            time_var.set(available_slots[0])  # Auto-select the first available slot

    # Buttons for shifts
    tk.Button(appointments_window, text="Morning (8AM - 12 PM)", command=lambda: update_time_slots("Morning")).pack(pady=2)
    tk.Button(appointments_window, text="Afternoon (1 PM - 5 PM)", command=lambda: update_time_slots("Afternoon")).pack(pady=2)
    #tk.Button(appointments_window, text="Evening (4 PM - 8 PM)", command=lambda: update_time_slots("Evening")).pack(pady=2)



    tk.Button(appointments_window, text="Update Appointment", command=edit_selected).pack(pady=5)
    tk.Button(appointments_window, text="Cancel Appointment", command=cancel_selected).pack(pady=5)


# Function to open the doctor search window
def open_doctor_search():

    if not receptionist_session.get('logged_in'):
        messagebox.showerror("Access Denied", "You must be logged in to access this page.")
        return

    print("open_doctor_search Called")

    search_window = tk.Toplevel()
    search_window.title("Search for a Doctor")
    search_window.geometry("400x400")
    
    tk.Label(search_window, text="Search Doctor by Name or Specialization:").pack()
    search_var = tk.StringVar()
    search_entry = ttk.Entry(search_window, textvariable=search_var)
    search_entry.pack()
    
    doctor_listbox = tk.Listbox(search_window)
    doctor_listbox.pack(fill=tk.BOTH, expand=True)
    
    def update_listbox():
        
        print("update_listbox inside open_doctor_search Called")

        doctor_listbox.delete(0, tk.END)
        query = search_var.get().lower()
        doctors = fetch_available_doctors()
        
        for doctor in doctors:
            if len(doctor) < 3:
                continue  # Skip improperly structured records

            doctor_id, doctor_name, specialization = doctor
            if query in doctor_name.lower() or query in specialization.lower():
                doctor_listbox.insert(tk.END, f"{doctor_id} - Dr. {doctor_name} ({specialization})")

    
    search_entry.bind("<KeyRelease>", lambda event: update_listbox())
    
    # def show_available_slots():
    #     print("show_available_slots inside open_doctor_search Called")

    #     selected = doctor_listbox.get(tk.ACTIVE)
    #     if not selected:
    #         return
    #     doctor_id = selected.split(" - ")[0]
    #     date = date_entry.get()
    #     available_slots = fetch_available_slots(doctor_id, date)
    #     slots_dropdown["values"] = available_slots

    def show_available_slots():
        print("show_available_slots Called")

        selected = doctor_listbox.get(tk.ACTIVE)
        if not selected:
            messagebox.showerror("Error", "No doctor selected!")
            return

        doctor_id = selected.split(" - ")[0].strip()
        raw_date = date_entry.get()

        # Convert MM/DD/YY (Tkinter DateEntry) → YYYY-MM-DD (Database)
        try:
            formatted_date = datetime.strptime(raw_date, "%m/%d/%y").strftime("%Y-%m-%d")
        except ValueError:
            messagebox.showerror("Error", "Invalid date format.")
            return

        print(f"Fetching available slots for Doctor ID: {doctor_id} on Date: {formatted_date}")

        available_slots = fetch_available_slots(doctor_id, formatted_date)

        if not available_slots:
            messagebox.showinfo("No Slots", "No available slots for this doctor on this date.")
        
        # Open a new window to show available slots
        slots_window = tk.Toplevel()
        slots_window.title("Available Slots")
        slots_window.geometry("300x300")

        tk.Label(slots_window, text=f"Available Slots for {selected}").pack(pady=5)

        slots_listbox = tk.Listbox(slots_window)
        for slot in available_slots:
            slots_listbox.insert(tk.END, slot)
        slots_listbox.pack(fill=tk.BOTH, expand=True)

        def select_slot():
            chosen_slot = slots_listbox.get(tk.ACTIVE)
            if chosen_slot:
                messagebox.showinfo("Slot Selected", f"You selected {chosen_slot} for {selected}")
                slots_window.destroy()
            else:
                messagebox.showerror("Error", "No slot selected.")

        tk.Button(slots_window, text="Select Slot", command=select_slot).pack(pady=5)


    
    tk.Label(search_window, text="Select Date:").pack()
    date_entry = DateEntry(search_window)
    date_entry.pack()
    
    tk.Button(search_window, text="Show Available Slots", command=show_available_slots).pack()
    
    tk.Label(search_window, text="Available Slots:").pack()
    slots_dropdown = ttk.Combobox(search_window)
    slots_dropdown.pack()
    
    tk.Button(search_window, text="Close", command=search_window.destroy).pack(pady=10)



# def open_patient_details():

#     if not receptionist_session.get('logged_in'):
#         messagebox.showerror("Access Denied", "You must be logged in to access this page.")
#         return
    
#     print("open_patient_details Called")

#     patients_window = tk.Toplevel()
#     patients_window.title("Patients List")
#     patients_window.geometry("800x600")

#     tk.Label(patients_window, text="All Patients", font=("Arial", 14, "bold")).pack(pady=10)

#     conn = sqlite3.connect('hospital.db')
#     cursor = conn.cursor()

#     cursor.execute("SELECT * from Patients order by id")

#     patients = cursor.fetchall()
#     conn.close()

#     tree = ttk.Treeview(patients_window, columns=("ID","Name","Age","Phone","Email"), show="headings")
#     tree.heading("ID", text="ID")
#     tree.heading("Name", text="Name")
#     tree.heading("Age", text="Age")
#     tree.heading("Phone", text="Phone")
#     tree.heading("Email", text="Email")
    
#     for pat in patients:
#         tree.insert("","end", values=pat)
    
#     tree.pack(expand=True, fill="both")



def open_patient_details():
    if not receptionist_session.get('logged_in'):
        messagebox.showerror("Access Denied", "You must be logged in to access this page.")
        return
    
    print("open_patient_details Called")
    
    def search_patient(*args):
        query = search_var.get()
        for item in tree.get_children():
            tree.delete(item)
        
        conn = sqlite3.connect('hospital.db')
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM Patients WHERE Name LIKE ? ORDER BY id", ('%' + query + '%',))
        patients = cursor.fetchall()
        conn.close()
        
        for pat in patients:
            tree.insert("", "end", values=pat)
    
    patients_window = tk.Toplevel()
    patients_window.title("Patients List")
    patients_window.geometry("800x600")
    
    tk.Label(patients_window, text="All Patients", font=("Arial", 14, "bold")).pack(pady=10)
    
    search_frame = tk.Frame(patients_window)
    search_frame.pack(pady=5)
    
    tk.Label(search_frame, text="Search by Name:").pack(side=tk.LEFT, padx=5)
    search_var = tk.StringVar()
    search_var.trace_add("write", search_patient)
    search_entry = tk.Entry(search_frame, textvariable=search_var)
    search_entry.pack(side=tk.LEFT, padx=5)
    # search_button = tk.Button(search_frame, text="Search", command=search_patient)
    # search_button.pack(side=tk.LEFT, padx=5)
    
    tree = ttk.Treeview(patients_window, columns=("ID", "Name", "Age", "Phone", "Email"), show="headings")
    tree.heading("ID", text="ID")
    tree.heading("Name", text="Name")
    tree.heading("Age", text="Age")
    tree.heading("Phone", text="Phone")
    tree.heading("Email", text="Email")
    tree.pack(expand=True, fill="both")
    
    conn = sqlite3.connect('hospital.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM Patients ORDER BY id")
    patients = cursor.fetchall()
    conn.close()
    
    for pat in patients:
        tree.insert("", "end", values=pat)



# def starting_page():
#     root = tk.Tk()
#     root.title("Starting Page")
#     root.geometry("400x300")

#     tk.Label(root, text="Welcome to the System", font=("Arial", 14, "bold")).pack(pady=20)

#     tk.Button(root, text="Get Started", command=receptionist_dashboard, width=30).pack(pady=10)
#     root.mainloop()








# Receptionist Dashboard UI
def receptionist_dashboard():
    

    if not receptionist_session.get('logged_in'):
        messagebox.showerror("Access Denied", "You must be logged in to access this page.")
        return
    
    print("receptionist_dashboard Called")

    


    global root

    root = tk.Tk()
    root.title("Receptionist Dashboard")
    root.geometry("800x600")

    tk.Label(root, text=f"Welcome {receptionist_session.get('user_name', 'Receptionist')}", font=("Arial", 14, "bold")).pack(pady=10)

    tk.Button(root, text="Logout", command=logout_receptionist, width=30).pack(pady=5)

    tk.Label(root, text="Receptionist Dashboard", font=("Arial", 16, "bold")).pack(pady=10)
    
    tk.Button(root, text="Register New Patient", command=lambda: open_patient_registration(), width=30).pack(pady=5)

    tk.Button(root, text="Book New Appointment", command=open_booking_form, width=30).pack(pady=5)

    tk.Button(root, text="View Appointments", command=open_appointment_list, width=30).pack(pady=5)

    tk.Button(root, text="Search for a Doctor", command=open_doctor_search, width=30).pack(pady=5)

    tk.Button(root, text="View All Patients", command=open_patient_details, width=30).pack(pady=5)

    # tk.Button(root, text="Search for a Patients", command=open_patient_search, width=30).pack(pady=5)
    


    root.mainloop()


def logout_receptionist():
    print("logout_receptionist called")
    Auth.logout()
    messagebox.showinfo("Logout", "Successfully Logged Out")
    root.destroy()
    subprocess.Popen(["python", "main_gui.py"])  # Open the main GUI
    
    

    
if __name__ == "__main__":
    start_scheduler()  # Start background scheduler

    receptionist_dashboard()
    #starting_page()
    
